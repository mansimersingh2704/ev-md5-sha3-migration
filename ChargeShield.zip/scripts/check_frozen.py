import sys
import os
import hashlib
from pathlib import Path

def compute_dir_hash(directory: Path) -> str:
    hasher = hashlib.sha3_256()
    for filepath in sorted(directory.rglob("*")):
        if filepath.is_file() and filepath.name != "sha3.lock":
            with open(filepath, "rb") as f:
                hasher.update(filepath.name.encode('utf-8'))
                hasher.update(f.read())
    return hasher.hexdigest()

def main():
    frozen_dir = Path("backend/app/legacy_frozen")
    lockfile = frozen_dir / "sha3.lock"
    
    current_hash = compute_dir_hash(frozen_dir)
    
    if "--generate" in sys.argv:
        with open(lockfile, "w") as f:
            f.write(current_hash)
        print(f"Generated lockfile with hash: {current_hash}")
        sys.exit(0)
        
    if not lockfile.exists():
        print("Error: sha3.lock not found.")
        sys.exit(1)
        
    with open(lockfile, "r") as f:
        expected_hash = f.read().strip()
        
    if current_hash != expected_hash:
        print(f"Error: legacy_frozen directory has been modified!\nExpected: {expected_hash}\nGot:      {current_hash}")
        sys.exit(1)
        
    print("legacy_frozen directory verified successfully.")
    sys.exit(0)

if __name__ == "__main__":
    main()
