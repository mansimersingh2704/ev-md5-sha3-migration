import { createFileRoute } from '@tanstack/react-router'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts'
import { useState } from 'react'
import { Activity } from 'lucide-react'

export const Route = createFileRoute('/benchmarks')({
  component: Benchmarks,
})

function Benchmarks() {
  const [data, setData] = useState<any[]>([])
  const [loading, setLoading] = useState(false)

  const runBenchmarks = async () => {
    setLoading(true)
    try {
      const res = await fetch('http://localhost:8000/benchmarks/run', {
        method: 'POST',
        headers: { 'Authorization': 'Bearer test' }
      })
      const result = await res.json()
      setData(result)
    } catch (e) {
      console.error(e)
    }
    setLoading(false)
  }

  const exportJSON = async () => {
    try {
      const res = await fetch('http://localhost:8000/reports/export', {
        headers: { 'Authorization': 'Bearer test' }
      })
      const result = await res.json()
      const blob = new Blob([JSON.stringify(result, null, 2)], { type: 'application/json' })
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = 'chargeshield-report.json'
      a.click()
    } catch (e) {
      console.error(e)
    }
  }

  const exportCSV = () => {
    if (!data.length) return
    const header = Object.keys(data[0]).join(',')
    const rows = data.map(obj => Object.values(obj).join(','))
    const csv = [header, ...rows].join('\n')
    const blob = new Blob([csv], { type: 'text/csv' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = 'benchmarks.csv'
    a.click()
  }

  return (
    <div>
      <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '1.5rem' }}>
        <Activity size={24} color="var(--accent-primary)" />
        <h2 style={{ margin: 0, fontSize: '1.5rem' }}>Benchmarks & Reports</h2>
      </div>

      <div style={{ display: 'flex', gap: '1rem', marginBottom: '2rem' }}>
        <button className="btn btn-primary" onClick={runBenchmarks} disabled={loading}>
          {loading ? 'Running...' : 'Run Benchmarks'}
        </button>
        <button className="btn" onClick={exportCSV} disabled={!data.length}>Export CSV</button>
        <button className="btn" onClick={exportJSON}>Export JSON Report</button>
      </div>

      {data.length > 0 && (
        <div style={{ backgroundColor: 'var(--bg-surface)', padding: '1.5rem', borderRadius: '0.5rem', height: '400px' }}>
          <h3 style={{ marginTop: 0 }}>Throughput (KB/s)</h3>
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={data}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border-color)" />
              <XAxis dataKey="algorithm" stroke="var(--text-muted)" />
              <YAxis stroke="var(--text-muted)" />
              <Tooltip contentStyle={{ backgroundColor: 'var(--bg-surface)', borderColor: 'var(--border-color)' }} />
              <Legend />
              <Bar dataKey="throughput_kb_s" fill="var(--accent-primary)" name="Throughput (KB/s)" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      )}
    </div>
  )
}
