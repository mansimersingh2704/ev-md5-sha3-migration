import { createFileRoute } from '@tanstack/react-router'
import { Key, ShieldAlert, ShieldCheck } from 'lucide-react'
import { useQuery } from '@tanstack/react-query'

export const Route = createFileRoute('/lab')({
  component: CollisionLab,
})

function CollisionLab() {
  const { data: data, isLoading, error } = useQuery({
    queryKey: ['collisions'],
    queryFn: async () => {
      const res = await fetch('http://localhost:8000/collisions/fixtures', {
        headers: { 'Authorization': 'Bearer test' }
      })
      if (!res.ok) throw new Error('Failed to fetch collisions')
      return res.json()
    }
  })
  
  const fixtures = data?.fixtures || []

  return (
    <div>
      <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '1.5rem' }}>
        <Key size={24} color="var(--accent-primary)" />
        <h2 style={{ margin: 0, fontSize: '1.5rem' }}>Collision Risk Lab</h2>
      </div>
      
      <div style={{ marginBottom: '1.5rem' }}>
        <span className="badge badge-public-test">PUBLIC-TEST-VECTOR</span>
        <p style={{ color: 'var(--text-muted)' }}>
          Demonstrates how identical MD5 checksums fail to protect firmware updates, and how the SHA-3 Compatibility Wrapper successfully detects and rejects the colliding blob.
        </p>
      </div>

      {isLoading && <p>Loading fixtures...</p>}
      {error && <p style={{ color: 'var(--status-error)' }}>Error: {(error as Error).message}</p>}

      <div style={{ display: 'flex', flexDirection: 'column', gap: '2rem' }}>
        {fixtures.map((fixture: any) => (
          <div key={fixture.name} style={{ backgroundColor: 'var(--bg-surface)', padding: '1.5rem', borderRadius: '0.5rem', border: '1px solid var(--border-color)' }}>
            <h3 style={{ marginTop: 0 }}>{fixture.description}</h3>
            {fixture.is_mock && (
              <p style={{ color: 'var(--status-warning)', fontSize: '0.9rem', marginBottom: '1rem' }}>
                Note: This is simulated placeholder data because real collision files were not found in the fixtures directory.
              </p>
            )}

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '2rem' }}>
              
              {/* Firmware 1 */}
              <div style={{ backgroundColor: 'rgba(0,0,0,0.2)', padding: '1rem', borderRadius: '0.5rem' }}>
                <h4 style={{ margin: '0 0 1rem 0' }}>Original Firmware Blob</h4>
                
                <div style={{ marginBottom: '1rem' }}>
                  <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)', marginBottom: '0.25rem' }}>Legacy Checksum (MD5)</div>
                  <div style={{ fontFamily: 'monospace', color: 'var(--status-success)', wordBreak: 'break-all' }}>{fixture.md5_1}</div>
                </div>
                
                <div>
                  <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)', marginBottom: '0.25rem' }}>Wrapper Integrity (SHA3-256)</div>
                  <div style={{ fontFamily: 'monospace', wordBreak: 'break-all' }}>{fixture.sha3_1}</div>
                </div>
              </div>

              {/* Firmware 2 */}
              <div style={{ backgroundColor: 'rgba(0,0,0,0.2)', padding: '1rem', borderRadius: '0.5rem' }}>
                <h4 style={{ margin: '0 0 1rem 0', color: 'var(--status-error)' }}>Malicious Swapped Blob</h4>
                
                <div style={{ marginBottom: '1rem' }}>
                  <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)', marginBottom: '0.25rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                    Legacy Checksum (MD5) <ShieldAlert size={14} color="var(--status-error)" />
                  </div>
                  <div style={{ fontFamily: 'monospace', color: 'var(--status-success)', wordBreak: 'break-all' }}>{fixture.md5_2} <span style={{ color: 'var(--status-error)', fontSize: '0.8rem' }}>(COLLISION!)</span></div>
                </div>
                
                <div>
                  <div style={{ fontSize: '0.8rem', color: 'var(--text-muted)', marginBottom: '0.25rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                    Wrapper Integrity (SHA3-256) <ShieldCheck size={14} color="var(--status-success)" />
                  </div>
                  <div style={{ fontFamily: 'monospace', color: 'var(--status-warning)', wordBreak: 'break-all' }}>{fixture.sha3_2}</div>
                </div>
              </div>

            </div>

            <div style={{ marginTop: '1.5rem', padding: '1rem', borderLeft: '4px solid var(--accent-primary)', backgroundColor: 'rgba(255,255,255,0.05)' }}>
              <strong>Scenario Result:</strong> In a Legacy Profile CSMS, both firmware blobs appear identical because their MD5 checksums match, allowing the malicious firmware to install. By verifying the appended SHA3-256 hash in DUAL or SHA3_ENFORCED mode, the proxy detects the difference and rejects the malicious blob.
            </div>
            
          </div>
        ))}
        {fixtures.length === 0 && !isLoading && (
          <p>No collision fixtures loaded.</p>
        )}
      </div>
    </div>
  )
}
