import { createFileRoute } from '@tanstack/react-router'
import { Radio, Plus, Activity } from 'lucide-react'
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query'

export const Route = createFileRoute('/stations')({
  component: Stations,
})

function Stations() {
  const queryClient = useQueryClient()

  const { data: stations, isLoading, error } = useQuery({
    queryKey: ['stations'],
    queryFn: async () => {
      const res = await fetch('http://localhost:8000/stations', {
        headers: { 'Authorization': 'Bearer test' }
      })
      if (!res.ok) throw new Error('Failed to fetch stations')
      return res.json()
    }
  })

  const addStation = useMutation({
    mutationFn: async (mode: string) => {
      const randomId = `CS-${Math.floor(Math.random() * 10000)}`
      const res = await fetch('http://localhost:8000/stations', {
        method: 'POST',
        headers: { 
          'Authorization': 'Bearer test',
          'Content-Type': 'application/json' 
        },
        body: JSON.stringify({
          station_id: randomId,
          key: `sim-key-${randomId}`,
          mode: mode
        })
      })
      if (!res.ok) throw new Error('Failed to add station')
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['stations'] })
      queryClient.invalidateQueries({ queryKey: ['audit'] })
    }
  })

  return (
    <div>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '1.5rem' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
          <Radio size={24} color="var(--accent-primary)" />
          <h2 style={{ margin: 0, fontSize: '1.5rem' }}>Charge Stations</h2>
        </div>
        
        <div style={{ display: 'flex', gap: '0.5rem' }}>
          <button 
            className="btn btn-secondary" 
            onClick={() => addStation.mutate('LEGACY_ONLY')}
            disabled={addStation.isPending}
            style={{ display: 'flex', alignItems: 'center', gap: '0.25rem' }}
          >
            <Plus size={16} /> Add Legacy CP
          </button>
          <button 
            className="btn btn-primary" 
            onClick={() => addStation.mutate('SHA3_ENFORCED')}
            disabled={addStation.isPending}
            style={{ display: 'flex', alignItems: 'center', gap: '0.25rem' }}
          >
            <Plus size={16} /> Add SHA-3 CP
          </button>
        </div>
      </div>

      <div style={{ marginBottom: '1.5rem' }}>
        <span className="badge badge-public-test">SIMULATED</span>
        <p style={{ color: 'var(--text-muted)', fontSize: '0.9rem', marginTop: '0.5rem' }}>
          These represent virtual OCPP 1.6 charging points connecting to our proxy. They don't have real hardware, but their crypto operations and wrapper negotiations execute accurately against the CSMS.
        </p>
      </div>

      {isLoading && <p>Loading stations...</p>}
      {error && <p style={{ color: 'var(--status-error)' }}>Error: {(error as Error).message}</p>}
      
      {!isLoading && !error && (
        <div style={{ backgroundColor: 'var(--bg-surface)', borderRadius: '0.5rem', border: '1px solid var(--border-color)', overflow: 'hidden' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', textAlign: 'left' }}>
            <thead style={{ backgroundColor: 'rgba(0,0,0,0.2)' }}>
              <tr>
                <th style={{ padding: '1rem', borderBottom: '1px solid var(--border-color)' }}>Station ID</th>
                <th style={{ padding: '1rem', borderBottom: '1px solid var(--border-color)' }}>Wrapper Mode</th>
                <th style={{ padding: '1rem', borderBottom: '1px solid var(--border-color)', textAlign: 'right' }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {stations?.length === 0 ? (
                <tr>
                  <td colSpan={3} style={{ padding: '2rem', textAlign: 'center', color: 'var(--text-muted)' }}>
                    No stations registered. Click the buttons above to spawn simulated charge points!
                  </td>
                </tr>
              ) : (
                stations?.map((s: any) => (
                  <tr key={s.id} style={{ transition: 'background-color 0.2s' }}>
                    <td style={{ padding: '1rem', borderBottom: '1px solid var(--border-color)', fontFamily: 'monospace' }}>{s.station_id}</td>
                    <td style={{ padding: '1rem', borderBottom: '1px solid var(--border-color)' }}>
                      <span className={`badge ${s.mode === 'SHA3_ENFORCED' ? 'badge-success' : 'badge-warning'}`}>
                        {s.mode}
                      </span>
                    </td>
                    <td style={{ padding: '1rem', borderBottom: '1px solid var(--border-color)', textAlign: 'right' }}>
                       <span style={{ fontSize: '0.8rem', color: 'var(--text-muted)' }}>Auto-syncing via websocket...</span>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}
