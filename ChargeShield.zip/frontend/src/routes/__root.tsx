import { createRootRoute, Link, Outlet } from '@tanstack/react-router'
import { Shield, Activity, Radio, Key, History } from 'lucide-react'

export const Route = createRootRoute({
  component: () => (
    <div style={{ display: 'flex', minHeight: '100vh' }}>
      <aside style={{ width: '250px', backgroundColor: 'var(--bg-surface)', borderRight: '1px solid var(--border-color)', padding: '1rem' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '2rem', color: 'var(--accent-primary)' }}>
          <Shield />
          <h1 style={{ fontSize: '1.25rem', margin: 0 }}>ChargeShield</h1>
        </div>
        <nav style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
          <Link to="/" style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', padding: '0.5rem', textDecoration: 'none', color: 'inherit', borderRadius: '0.25rem' }} activeProps={{ style: { backgroundColor: 'var(--bg-surface-hover)' } }}>
            <Activity size={18} /> Command Center
          </Link>
          <Link to="/stations" style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', padding: '0.5rem', textDecoration: 'none', color: 'inherit', borderRadius: '0.25rem' }} activeProps={{ style: { backgroundColor: 'var(--bg-surface-hover)' } }}>
            <Radio size={18} /> Stations
          </Link>
          <Link to="/lab" style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', padding: '0.5rem', textDecoration: 'none', color: 'inherit', borderRadius: '0.25rem' }} activeProps={{ style: { backgroundColor: 'var(--bg-surface-hover)' } }}>
            <Key size={18} /> Collision Lab
          </Link>
          <Link to="/migration" style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', padding: '0.5rem', textDecoration: 'none', color: 'inherit', borderRadius: '0.25rem' }} activeProps={{ style: { backgroundColor: 'var(--bg-surface-hover)' } }}>
            <History size={18} /> Migration
          </Link>
          <Link to="/benchmarks" style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', padding: '0.5rem', textDecoration: 'none', color: 'inherit', borderRadius: '0.25rem' }} activeProps={{ style: { backgroundColor: 'var(--bg-surface-hover)' } }}>
            <Activity size={18} /> Benchmarks
          </Link>
        </nav>
      </aside>
      <main style={{ flex: 1, padding: '2rem' }}>
        <Outlet />
      </main>
    </div>
  ),
})
