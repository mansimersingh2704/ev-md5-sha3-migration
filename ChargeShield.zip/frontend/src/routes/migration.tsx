import { createFileRoute } from '@tanstack/react-router'
import { History } from 'lucide-react'
import { useQuery } from '@tanstack/react-query'

export const Route = createFileRoute('/migration')({
  component: Migration,
})

function Migration() {
  const { data: logs, isLoading, error } = useQuery({
    queryKey: ['audit'],
    queryFn: async () => {
      const res = await fetch('http://localhost:8000/audit/logs', {
        headers: { 'Authorization': 'Bearer test' }
      })
      if (!res.ok) throw new Error('Failed to fetch logs')
      return res.json()
    }
  })

  return (
    <div>
      <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '1.5rem' }}>
        <History size={24} color="var(--accent-primary)" />
        <h2 style={{ margin: 0, fontSize: '1.5rem' }}>Migration Audit Log</h2>
      </div>

      {isLoading && <p>Loading logs...</p>}
      {error && <p style={{ color: 'var(--status-error)' }}>Error: {(error as Error).message}</p>}
      
      {!isLoading && !error && (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
          {logs?.length === 0 ? (
            <p style={{ color: 'var(--text-muted)' }}>No audit logs found.</p>
          ) : (
            logs?.map((log: any) => (
              <div key={log.id} style={{ backgroundColor: 'var(--bg-surface)', padding: '1rem', borderRadius: '0.5rem', border: '1px solid var(--border-color)', position: 'relative' }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.5rem' }}>
                  <strong>{log.action}</strong>
                  <span style={{ fontSize: '0.875rem', color: 'var(--text-muted)' }}>{new Date(log.timestamp).toLocaleString()}</span>
                </div>
                <p style={{ margin: '0 0 0.5rem 0', fontSize: '0.875rem' }}>Target: {log.target}</p>
                <div style={{ fontSize: '0.75rem', fontFamily: 'monospace', color: 'var(--text-muted)', backgroundColor: 'rgba(0,0,0,0.2)', padding: '0.5rem', borderRadius: '0.25rem' }}>
                  <div>Hash: {log.hash.substring(0, 16)}...</div>
                  <div>Prev: {log.previous_hash.substring(0, 16)}...</div>
                </div>
              </div>
            ))
          )}
        </div>
      )}
    </div>
  )
}
