import { createFileRoute } from '@tanstack/react-router'
import { Activity } from 'lucide-react'
import { useQuery } from '@tanstack/react-query'

export const Route = createFileRoute('/')({
  component: Index,
})

function Index() {
  const { data: stations, isLoading } = useQuery({
    queryKey: ['stations'],
    queryFn: async () => {
      const res = await fetch('http://localhost:8000/stations', {
        headers: { 'Authorization': 'Bearer test' }
      })
      if (!res.ok) throw new Error('Failed to fetch stations')
      return res.json()
    }
  })

  return (
    <div>
      <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '1.5rem' }}>
        <Activity size={24} color="var(--accent-primary)" />
        <h2 style={{ margin: 0, fontSize: '1.5rem' }}>Command Center</h2>
      </div>
      
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '1rem' }}>
        <div style={{ backgroundColor: 'var(--bg-surface)', padding: '1.5rem', borderRadius: '0.5rem', border: '1px solid var(--border-color)' }}>
          <h3 style={{ marginTop: 0 }}>System Status</h3>
          <p style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            <span style={{ width: '10px', height: '10px', borderRadius: '50%', backgroundColor: 'var(--status-success)', display: 'inline-block' }}></span>
            Simulator Online
          </p>
          <div style={{ marginTop: '1rem' }}>
            <span className="badge badge-simulated">SIMULATED ENVIRONMENT</span>
          </div>
        </div>
        
        <div style={{ backgroundColor: 'var(--bg-surface)', padding: '1.5rem', borderRadius: '0.5rem', border: '1px solid var(--border-color)' }}>
          <h3 style={{ marginTop: 0 }}>Active Stations</h3>
          <p style={{ fontSize: '2rem', fontWeight: 'bold', margin: '0.5rem 0' }}>
            {isLoading ? '...' : (stations?.length || 0)}
          </p>
        </div>
      </div>
    </div>
  )
}
