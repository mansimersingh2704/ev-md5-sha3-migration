import { test, expect } from '@playwright/test';

test('has title and navigates to stations', async ({ page }) => {
  await page.goto('/');

  // Expect a title "to contain" a substring.
  await expect(page.locator('h1')).toHaveText('ChargeShield');
  await expect(page.getByRole('heading', { name: 'Command Center' })).toBeVisible();

  // Navigate to Stations
  await page.click('text=Stations');
  await expect(page.locator('text=Charge Stations')).toBeVisible();
});

test('navigates to collision lab', async ({ page }) => {
  await page.goto('/');
  await page.click('text=Collision Lab');
  await expect(page.locator('text=PUBLIC-TEST-VECTOR')).toBeVisible();
});

test('navigates to migration', async ({ page }) => {
  await page.goto('/');
  await page.click('text=Migration');
  await expect(page.locator('text=Migration Audit Log')).toBeVisible();
});

test('navigates to benchmarks and displays charts', async ({ page }) => {
  await page.route('**/benchmarks/run', route => route.fulfill({
    status: 200,
    contentType: 'application/json',
    body: JSON.stringify([{ algorithm: 'MD5', latency_ms: 1, throughput_kb_s: 100 }])
  }));
  await page.goto('/');
  await page.click('text=Benchmarks');
  await expect(page.locator('text=Benchmarks & Reports')).toBeVisible();
  
  await page.click('text=Run Benchmarks');
  // the text changes to Running... then back, and a chart appears.
  await expect(page.locator('text=Throughput (KB/s)')).toBeVisible({ timeout: 10000 });
});
