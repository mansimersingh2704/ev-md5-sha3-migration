Task: P4 Frontend Workspaces
Context: Building the UI to interact with the ChargeShield platform.
Objective: Implement the React Vite frontend matching the reference repo's design language.
Relevant Docs: reference repo structure.
In Scope: TanStack Router setup, Command Center, Stations, Collision Lab, Wrapper, Migration routes.
Out of Scope: Benchmarks UI, backend implementation.
Implementation Requirements: Dark SCADA style, semantic CSS tokens, TanStack Query, Radix UI. Badges for SIMULATED data. Keyboard accessible.
Acceptance Criteria:
- All routes functional with loading/error states.
- Provenance badges visible.
- Matches design tokens.
Verification: oxlint, Playwright E2E tests, Vite build.
Stop Condition: E2E tests pass for navigation and data display.
