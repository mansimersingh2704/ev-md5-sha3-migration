Task: P1 Crypto & Wrapper
Context: Initial phase establishing the core security upgrades and the proxy layer.
Objective: Implement the SHA-3 Compatibility Wrapper, the frozen legacy MD5 parser, and the core cryptographic functions.
Relevant Docs: docs/architecture, AGENTS.md
In Scope: Python crypto module (SHA-3, HMAC), frozen legacy parser mock, Wrapper proxy/middleware, hypothesis testing.
Out of Scope: API endpoints, UI, database, simulator logic.
Implementation Requirements: Use hashlib for SHA-3. Wrapper must strictly not modify MD5 field. Strict typing. Pytest with hypothesis tests.
Acceptance Criteria: 
- Frozen legacy parser accepts wrapped messages without error.
- Wrapper correctly appends customData extension.
- Pytest coverage > 85%.
Verification: Run pytest on backend.
Stop Condition: All tests pass and wrapper logic is fully covered.
