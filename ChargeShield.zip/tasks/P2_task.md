Task: P2 Simulator & Lab
Context: Setting up the environment to demonstrate collision risks.
Objective: Build the OCPP 1.6J simulator and load public MD5 collision fixtures.
Relevant Docs: AGENTS.md, public test vectors.
In Scope: Local charge point/CSMS simulation over websockets, collision test vector loading, risk scoring calculation.
Out of Scope: Real network communication, frontend lab UI.
Implementation Requirements: Must use only pre-generated public MD5 collision fixtures. Label as SIMULATED.
Acceptance Criteria:
- Simulator connects locally.
- Collision pairs load and correctly compute different SHA-3 hashes despite identical MD5.
- Risk score calculated accurately.
Verification: Backend pytest for simulator and risk scoring.
Stop Condition: Collision fixtures are verified by tests to match MD5 and differ in SHA-3.
