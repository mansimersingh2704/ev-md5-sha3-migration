Task: P3 API & Backend Systems
Context: Exposing the core logic and simulator state to the frontend.
Objective: Implement the FastAPI endpoints, database models, auth, and audit logs.
Relevant Docs: API contract list.
In Scope: FastAPI routing, SQLAlchemy models (SQLite dev), JWT auth, append-only audit log.
Out of Scope: Production PostgreSQL setup, Frontend consumption.
Implementation Requirements: Pydantic v2 validation. Structured logging. Audit log hash-chained with SHA3-256.
Acceptance Criteria:
- Endpoints return expected schemas.
- DB stores configuration and state.
- Audit log correctly chains hashes.
Verification: Backend API tests with pytest.
Stop Condition: All API routes tested and database schema deployed via Alembic.
