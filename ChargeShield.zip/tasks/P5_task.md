Task: P5 Benchmarks & Reports
Context: Finalizing the features for evaluation and auditing.
Objective: Implement benchmarking for hash throughput/latency and report generation.
Relevant Docs: AGENTS.md.
In Scope: Benchmarking endpoints and UI charts, CSV export, PDF/JSON findings report.
Out of Scope: Infrastructure changes.
Implementation Requirements: Recharts for UI. Accurate timing for benchmark tests.
Acceptance Criteria:
- Benchmarks execute and render charts.
- Export to CSV/JSON functions properly.
Verification: Playwright E2E for report downloading, backend tests for benchmark accuracy.
Stop Condition: Benchmarks run without error and export files are valid.
