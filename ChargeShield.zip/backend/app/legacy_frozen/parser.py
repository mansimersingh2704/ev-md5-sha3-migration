import json
from typing import Any


class LegacyParserError(Exception):
    pass

def parse_legacy_message(message_json: str, strict: bool = False) -> dict[str, Any]:
    """
    Simulates the frozen legacy parser.
    It expects OCPP JSON format: [MessageTypeId, UniqueId, Action, Payload]
    """
    try:
        msg = json.loads(message_json)
    except json.JSONDecodeError:
        raise LegacyParserError("Invalid JSON")

    if not isinstance(msg, list) or len(msg) not in (4, 5):
        raise LegacyParserError("Invalid OCPP message format")

    msg_type = msg[0]
    if msg_type == 2:  # CALL
        unique_id = msg[1]
        action = msg[2]
        payload = msg[3]
    elif msg_type == 3:  # CALLRESULT
        unique_id = msg[1]
        action = "Unknown" # Action is not in CALLRESULT
        payload = msg[2]
    else:
        raise LegacyParserError(f"Unsupported message type {msg_type}")

    if not isinstance(payload, dict):
        raise LegacyParserError("Payload must be an object")

    # Strict validation for known actions
    if strict:
        if action == "UpdateFirmware":
            # strict schema checking
            allowed_keys = {"location", "retries", "retrieveDate", "retryInterval", "metadata"}
            if not set(payload.keys()).issubset(allowed_keys):
                raise LegacyParserError("Strict validation failed: unknown fields in UpdateFirmware payload")
            if "metadata" in payload:
                if not set(payload["metadata"].keys()).issubset({"md5Checksum"}):
                    raise LegacyParserError("Strict validation failed: unknown fields in metadata")
        
        elif action == "DataTransfer":
            allowed_keys = {"vendorId", "messageId", "data"}
            if not set(payload.keys()).issubset(allowed_keys):
                raise LegacyParserError("Strict validation failed: unknown fields in DataTransfer payload")
            if payload.get("vendorId") == "ChargeShield_Legacy":
                if "data" in payload and isinstance(payload["data"], dict):
                    if not set(payload["data"].keys()).issubset({"md5Checksum"}):
                        raise LegacyParserError("Strict validation failed: unknown fields in DataTransfer data")

    return {
        "msg_type": msg_type,
        "unique_id": unique_id,
        "action": action,
        "payload": payload
    }

def get_md5_from_legacy(payload: dict[str, Any]) -> str | None:
    """Extracts MD5 from legacy payloads, simulating legacy verification."""
    if "metadata" in payload and isinstance(payload["metadata"], dict):
        return str(payload["metadata"].get("md5Checksum")) if payload["metadata"].get("md5Checksum") else None
    if "data" in payload and isinstance(payload["data"], dict):
        return str(payload["data"].get("md5Checksum")) if payload["data"].get("md5Checksum") else None
    return None
