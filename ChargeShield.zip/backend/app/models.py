import hashlib
import json
from datetime import datetime, timezone

from sqlalchemy import Column, DateTime, ForeignKey, Integer, String, Text

from .db import Base


class User(Base): # type: ignore
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    username = Column(String, unique=True, index=True, nullable=False)
    hashed_password = Column(String, nullable=False)

class Station(Base): # type: ignore
    __tablename__ = "stations"

    id = Column(Integer, primary_key=True, index=True)
    station_id = Column(String, unique=True, index=True, nullable=False)
    key = Column(String, nullable=False)
    mode = Column(String, default="SHA3_ENFORCED", nullable=False) # LEGACY_ONLY, DUAL, SHA3_ENFORCED

class AuditLog(Base): # type: ignore
    __tablename__ = "audit_logs"

    id = Column(Integer, primary_key=True, index=True)
    timestamp = Column(DateTime, default=lambda: datetime.now(timezone.utc), nullable=False)
    action = Column(String, nullable=False)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    target = Column(String, nullable=True)
    details = Column(Text, nullable=True) # JSON string
    previous_hash = Column(String, nullable=False)
    hash = Column(String, nullable=False)

    def compute_hash(self) -> str:
        """Compute SHA3-256 hash of this record including previous hash."""
        record = {
            "timestamp": self.timestamp.isoformat() if self.timestamp else None,
            "action": self.action,
            "user_id": self.user_id,
            "target": self.target,
            "details": self.details,
            "previous_hash": self.previous_hash
        }
        canonical_str = json.dumps(record, separators=(',', ':'), sort_keys=True)
        return hashlib.sha3_256(canonical_str.encode('utf-8')).hexdigest()
