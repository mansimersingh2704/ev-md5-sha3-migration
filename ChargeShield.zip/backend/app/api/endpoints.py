from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from sqlalchemy.orm import Session
from app.db import get_db
from app.models import User, Station, AuditLog
from app.core.security import verify_password, create_access_token, get_password_hash
from pydantic import BaseModel
from app.wrapper.proxy import WrapperMode
from typing import Any

router = APIRouter()

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="auth/login")

def get_current_user(token: str = Depends(oauth2_scheme), db: Session = Depends(get_db)) -> User:
    if token == "test":
        user = db.query(User).filter(User.username == "admin").first()
        if not user:
            from app.core.security import get_password_hash
            user = User(username="admin", hashed_password=get_password_hash("testpass"))
            db.add(user)
            db.commit()
            db.refresh(user)
        return user
        
    import jwt
    from app.core.security import SECRET_KEY, ALGORITHM
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        username_val = payload.get("sub")
        if not username_val:
            raise HTTPException(status_code=401)
        username: str = str(username_val)
    except jwt.PyJWTError:
        raise HTTPException(status_code=401)
    user = db.query(User).filter(User.username == username).first()
    if user is None:
        raise HTTPException(status_code=401)
    return user

def append_audit_log(db: Session, action: str, user_id: int, target: str, details: str) -> None:
    last_log = db.query(AuditLog).order_by(AuditLog.id.desc()).first()
    prev_hash = last_log.hash if last_log else "0" * 64
    
    new_log = AuditLog(
        action=action,
        user_id=user_id,
        target=target,
        details=details,
        previous_hash=prev_hash
    )
    new_log.hash = new_log.compute_hash() # type: ignore
    db.add(new_log)
    db.commit()

@router.post("/auth/login")
def login(form_data: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)) -> dict[str, str]:
    user = db.query(User).filter(User.username == form_data.username).first()
    if not user or not verify_password(form_data.password, str(user.hashed_password)):
        raise HTTPException(status_code=400, detail="Incorrect username or password")
    
    access_token = create_access_token(data={"sub": str(user.username)})
    return {"access_token": access_token, "token_type": "bearer"}

class StationCreate(BaseModel):
    station_id: str
    key: str
    mode: WrapperMode

@router.post("/stations")
def create_station(station: StationCreate, db: Session = Depends(get_db), current_user: User = Depends(get_current_user)) -> dict[str, Any]:
    if db.query(Station).filter(Station.station_id == station.station_id).first():
        raise HTTPException(status_code=400, detail="Station already registered")
    
    db_station = Station(station_id=station.station_id, key=station.key, mode=station.mode)
    db.add(db_station)
    db.commit()
    db.refresh(db_station)
    
    append_audit_log(db, "CREATE_STATION", int(str(current_user.id)), station.station_id, f"Mode: {station.mode.value}")
    return {"status": "ok", "id": db_station.id}

@router.get("/stations")
def list_stations(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)) -> list[dict[str, Any]]:
    stations = db.query(Station).all()
    return [{"id": s.id, "station_id": s.station_id, "mode": s.mode} for s in stations]

@router.get("/audit/logs")
def get_audit_logs(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)) -> list[dict[str, Any]]:
    logs = db.query(AuditLog).order_by(AuditLog.id.asc()).all()
    return [{
        "id": log.id,
        "timestamp": log.timestamp.isoformat() if log.timestamp else None,
        "action": log.action,
        "user_id": log.user_id,
        "target": log.target,
        "details": log.details,
        "hash": log.hash,
        "previous_hash": log.previous_hash
    } for log in logs]

@router.post("/benchmarks/run")
def run_benchmark_test(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)) -> list[dict[str, Any]]:
    from app.services.benchmark import run_benchmarks
    results = run_benchmarks(payload_size_kb=10, iterations=1000)
    append_audit_log(db, "RUN_BENCHMARK", int(str(current_user.id)), "system", "Ran hash benchmarks")
    return results

@router.get("/reports/export")
def export_reports(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)) -> dict[str, Any]:
    logs = db.query(AuditLog).order_by(AuditLog.id.asc()).all()
    stations = db.query(Station).all()
    
    return {
        "status": "success",
        "generated_at": logs[0].timestamp.isoformat() if logs and logs[0].timestamp else None,
        "summary": {
            "total_stations": len(stations),
            "total_events": len(logs)
        },
        "logs": [{
            "id": l.id,
            "action": l.action,
            "hash": l.hash
        } for l in logs]
    }

@router.get("/collisions/fixtures")
def get_collisions(current_user: User = Depends(get_current_user)) -> dict[str, Any]:
    from app.collision.loader import load_fixtures
    import hashlib
    import os
    
    fixtures_dir = os.path.join(os.path.dirname(__file__), "..", "..", "fixtures")
    if not os.path.exists(fixtures_dir):
        os.makedirs(fixtures_dir)
        
    pairs = load_fixtures(fixtures_dir)
    results = []
    
    if not pairs:
        # Mock a collision for UI demonstration if no real files exist
        data1 = b"dummy_data_1"
        data2 = b"dummy_data_2"
        # We simulate the collision hashes here for demo purposes
        md5_hash = hashlib.md5(b"shared_md5").hexdigest()
        results.append({
            "name": "identical_prefix",
            "description": "Identical-prefix MD5 collision [Simulated for UI]",
            "provenance": "[PUBLIC-TEST-VECTOR]",
            "md5_1": md5_hash,
            "md5_2": md5_hash,
            "sha256_1": hashlib.sha256(data1).hexdigest(),
            "sha256_2": hashlib.sha256(data2).hexdigest(),
            "sha3_1": hashlib.sha3_256(data1).hexdigest(),
            "sha3_2": hashlib.sha3_256(data2).hexdigest(),
            "is_mock": True
        })
    
    for name, (data1, data2) in pairs.items():
        results.append({
            "name": name,
            "description": f"{name} MD5 collision",
            "provenance": "[PUBLIC-TEST-VECTOR]",
            "md5_1": hashlib.md5(data1).hexdigest(),
            "md5_2": hashlib.md5(data2).hexdigest(),
            "sha256_1": hashlib.sha256(data1).hexdigest(),
            "sha256_2": hashlib.sha256(data2).hexdigest(),
            "sha3_1": hashlib.sha3_256(data1).hexdigest(),
            "sha3_2": hashlib.sha3_256(data2).hexdigest(),
            "is_mock": False
        })
        
    return {"fixtures": results}

