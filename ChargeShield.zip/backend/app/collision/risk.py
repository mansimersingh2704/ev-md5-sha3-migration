from pydantic import BaseModel


class RiskScore(BaseModel):
    message_type: str
    likelihood: float
    impact: float
    score: float # 0-100
    factors: list[str]

def calculate_risk(message_type: str, mode: str) -> RiskScore:
    """
    Calculates a risk score (0-100) based on message type and current wrapper mode.
    Factors:
    - UpdateFirmware: Highest impact (system compromise). Likelihood high in LEGACY_ONLY due to MD5.
    - DataTransfer: Medium impact (data spoofing).
    """
    if message_type == "UpdateFirmware":
        impact = 10.0
        if mode == "LEGACY_ONLY":
            likelihood = 9.0
            factors = ["MD5 is vulnerable to collision attacks", "Full system compromise possible"]
        elif mode == "DUAL":
            likelihood = 4.0
            factors = ["SHA-3 provides collision resistance", "Downgrade attack still possible"]
        else: # SHA3_ENFORCED
            likelihood = 1.0
            factors = ["HMAC-SHA3-256 enforced", "Protected against collision and downgrade attacks"]
            
    elif message_type == "DataTransfer":
        impact = 6.0
        if mode == "LEGACY_ONLY":
            likelihood = 8.0
            factors = ["Payload data spoofing possible via MD5 collision"]
        elif mode == "DUAL":
            likelihood = 3.0
            factors = ["SHA-3 provides collision resistance", "Downgrade attack still possible"]
        else:
            likelihood = 1.0
            factors = ["HMAC-SHA3-256 enforced", "Protected against tamper and downgrade"]
            
    else:
        impact = 2.0
        likelihood = 1.0
        factors = ["Low risk message type"]
        
    score = min(100.0, (likelihood * impact))
    
    return RiskScore(
        message_type=message_type,
        likelihood=likelihood,
        impact=impact,
        score=score,
        factors=factors
    )
