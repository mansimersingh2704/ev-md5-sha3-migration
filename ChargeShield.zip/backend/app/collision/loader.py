import hashlib
import os

from pydantic import BaseModel


class CollisionFixture(BaseModel):
    name: str
    description: str
    file1_path: str
    file2_path: str
    provenance: str = "[PUBLIC-TEST-VECTOR]"

def load_fixtures(fixtures_dir: str) -> dict[str, tuple[bytes, bytes]]:
    """
    Loads public MD5 collision fixtures.
    Validates that MD5 is equal, but SHA-256 and SHA-3-256 are different.
    If missing, skips with a message.
    """
    loaded = {}
    
    # We expect identical-prefix and chosen-prefix pairs to be manually placed here by the user
    # e.g., identical1.bin / identical2.bin
    expected_pairs = {
        "identical_prefix": ("identical1.bin", "identical2.bin"),
        "chosen_prefix": ("chosen1.bin", "chosen2.bin")
    }
    
    for pair_name, (f1_name, f2_name) in expected_pairs.items():
        f1_path = os.path.join(fixtures_dir, f1_name)
        f2_path = os.path.join(fixtures_dir, f2_name)
        
        if not os.path.exists(f1_path) or not os.path.exists(f2_path):
            print(f"Skipping '{pair_name}': Files '{f1_name}' and/or '{f2_name}' not found. "
                  f"Please generate or download public MD5 collision fixtures and place them in {fixtures_dir}.")
            continue
            
        with open(f1_path, "rb") as f:
            data1 = f.read()
        with open(f2_path, "rb") as f:
            data2 = f.read()
            
        # Validation
        md5_1 = hashlib.md5(data1).hexdigest()
        md5_2 = hashlib.md5(data2).hexdigest()
        
        if md5_1 != md5_2:
            print(f"Error loading '{pair_name}': MD5 hashes do not match! ({md5_1} != {md5_2})")
            continue
            
        sha256_1 = hashlib.sha256(data1).hexdigest()
        sha256_2 = hashlib.sha256(data2).hexdigest()
        
        if sha256_1 == sha256_2:
            print(f"Error loading '{pair_name}': SHA-256 hashes are unexpectedly equal!")
            continue
            
        sha3_1 = hashlib.sha3_256(data1).hexdigest()
        sha3_2 = hashlib.sha3_256(data2).hexdigest()
        
        if sha3_1 == sha3_2:
            print(f"Error loading '{pair_name}': SHA-3 hashes are unexpectedly equal!")
            continue
            
        loaded[pair_name] = (data1, data2)
        print(f"Successfully loaded and validated {pair_name} [PUBLIC-TEST-VECTOR]")
        
    return loaded
