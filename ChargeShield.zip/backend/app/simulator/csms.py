import hashlib
from typing import Any

from app.legacy_frozen.parser import LegacyParserError, parse_legacy_message
from app.wrapper.proxy import (
    DowngradeError,
    ValidationError,
    WrapperMode,
    unwrap_and_verify,
)
from pydantic import BaseModel


class StationState(BaseModel):
    station_id: str
    key: str
    mode: WrapperMode

class CSMS:
    def __init__(self) -> None:
        # Server-side state: capability never derived from message content!
        self.stations: dict[str, StationState] = {}
        self.sidecar_buffer: dict[str, list[Any]] = {} # referenceId -> sidecar_msg
        
    def register_station(self, station_id: str, key: str, mode: WrapperMode) -> None:
        self.stations[station_id] = StationState(station_id=station_id, key=key, mode=mode)
        
    def handle_message(self, station_id: str, msgs: list[list[Any]], blob: bytes) -> dict[str, Any]:
        """
        Handles incoming WS messages from CP.
        Validates through wrapper, then passes to legacy parser.
        Then verifies if the blob MD5 matches.
        """
        if station_id not in self.stations:
            return {"status": "Rejected", "reason": "Unknown station"}
            
        state = self.stations[station_id]
        
        primary_msg = msgs[0]
        sidecar_msg = msgs[1] if len(msgs) > 1 else None
        
        # 1. Un-wrap and verify (Downgrade protection happens here!)
        try:
            unwrapped, extracted_sha3 = unwrap_and_verify(
                msg=primary_msg,
                mode=state.mode,
                station_id=station_id,
                key=state.key,
                sidecar_msg=sidecar_msg
            )
        except DowngradeError:
            return {"status": "Rejected", "reason": "Downgrade Attack Detected"}
        except ValidationError:
            return {"status": "Rejected", "reason": "HMAC Validation Failed"}
            
        # 2. Legacy Parser
        import json
        try:
            # tolerant mode for inband
            parsed = parse_legacy_message(json.dumps(unwrapped), strict=False)
        except LegacyParserError:
            return {"status": "Rejected", "reason": "Legacy Parser Error"}
            
        # 3. Simulate backend checking the MD5 of the blob against the parsed metadata
        payload = parsed["payload"]
        legacy_md5 = None
        if parsed["action"] == "UpdateFirmware" and "metadata" in payload:
            legacy_md5 = payload["metadata"].get("md5Checksum")
        elif parsed["action"] == "DataTransfer" and "data" in payload:
            legacy_md5 = payload["data"].get("md5Checksum")
            
        if not legacy_md5:
            return {"status": "Rejected", "reason": "Missing legacy MD5"}
            
        actual_md5 = hashlib.md5(blob).hexdigest()
        
        # Scenario detection logic:
        # If legacy MD5 matches, legacy systems would accept it.
        # But if we have an extracted SHA3 digest from the wrapper, we verify it against the actual SHA3 of the blob!
        actual_sha3 = hashlib.sha3_256(blob).hexdigest()
        sha3_matched = (extracted_sha3 == actual_sha3) if extracted_sha3 else None
        
        if legacy_md5 == actual_md5:
            # MD5 matches
            if sha3_matched is False:
                # Collision detected!
                return {"status": "Rejected", "reason": "Collision Detected by SHA-3"}
            return {"status": "Accepted", "reason": "MD5 Matched [SIMULATED]"}
        else:
            return {"status": "Rejected", "reason": "MD5 Mismatch"}
