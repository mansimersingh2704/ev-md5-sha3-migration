import hashlib
from typing import Any

from app.wrapper.proxy import WrapperMode, wrap_message


class ChargePoint:
    def __init__(self, station_id: str, key: str, mode: WrapperMode):
        self.station_id = station_id
        self.key = key
        self.mode = mode
        self.message_counter = 1
        
    def generate_unique_id(self) -> str:
        uid = str(self.message_counter)
        self.message_counter += 1
        return uid

    def create_firmware_update_req(self, firmware_blob: bytes) -> list[Any]:
        """Creates a Legacy Profile UpdateFirmware.req"""
        md5_hash = hashlib.md5(firmware_blob).hexdigest()
        sha3_hash = hashlib.sha3_256(firmware_blob).hexdigest()
        payload = {
            "location": "http://127.0.0.1/firmware.bin",
            "retries": 3,
            "retrieveDate": "2026-01-01T00:00:00Z",
            "retryInterval": 10,
            "metadata": {
                "md5Checksum": md5_hash
            }
        }
        msg = [2, self.generate_unique_id(), "UpdateFirmware", payload]
        
        # Wrap message according to CP mode
        wrapped_msgs = wrap_message(
            msg, 
            mode=self.mode, 
            station_id=self.station_id, 
            key=self.key, 
            nonce="nonce_cp", 
            timestamp="2026-01-01T00:00:00Z",
            blob_hash=sha3_hash
        )
        return wrapped_msgs

    def create_data_transfer_req(self, data_blob: bytes) -> list[Any]:
        """Creates a Legacy Profile DataTransfer.req"""
        md5_hash = hashlib.md5(data_blob).hexdigest()
        sha3_hash = hashlib.sha3_256(data_blob).hexdigest()
        payload = {
            "vendorId": "ChargeShield_Legacy",
            "messageId": "Telemetry",
            "data": {
                "md5Checksum": md5_hash,
                "telemetry": "sample_data"
            }
        }
        msg = [2, self.generate_unique_id(), "DataTransfer", payload]
        
        # Wrap message according to CP mode
        wrapped_msgs = wrap_message(
            msg, 
            mode=self.mode, 
            station_id=self.station_id, 
            key=self.key, 
            nonce="nonce_cp", 
            timestamp="2026-01-01T00:00:00Z",
            blob_hash=sha3_hash
        )
        return wrapped_msgs
