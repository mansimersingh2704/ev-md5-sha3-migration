import hashlib

from app.simulator.csms import CSMS
from app.wrapper.proxy import WrapperMode, wrap_message


class ScenarioResult:
    def __init__(self, mode: WrapperMode, accepted: bool, reason: str):
        self.mode = mode
        self.accepted = accepted
        self.reason = reason
        self.provenance = "[SCENARIO] [SIMULATED]"

def run_firmware_substitution_scenario(
    mode: WrapperMode, 
    benign_blob: bytes, 
    colliding_blob: bytes,
    key: str = "secret",
    station_id: str = "CP1"
) -> ScenarioResult:
    """
    Simulates a CSMS->CP or CP->CSMS firmware update where the attacker swaps the blob.
    We'll model CP -> CSMS telemetry reporting the firmware, but the attack model is the same.
    """
    csms = CSMS()
    csms.register_station(station_id, key, mode)
    
    # 1. CP prepares UpdateFirmware message with the benign blob
    benign_md5 = hashlib.md5(benign_blob).hexdigest()
    benign_sha3 = hashlib.sha3_256(benign_blob).hexdigest()
    
    payload = {
        "location": "http://127.0.0.1/firmware.bin",
        "retries": 3,
        "retrieveDate": "2026-01-01T00:00:00Z",
        "retryInterval": 10,
        "metadata": {
            "md5Checksum": benign_md5
        }
    }
    
    msg = [2, "uid123", "UpdateFirmware", payload]
    
    # Wrap it, injecting the sha3 of the benign blob!
    wrapped_msgs = wrap_message(msg, mode, station_id, key, blob_hash=benign_sha3)
    
    # 2. Attacker intercepts and swaps the firmware blob on the wire (but leaves messages intact)
    # The CSMS will receive `wrapped_msgs` but `colliding_blob` instead of `benign_blob`.
    
    result = csms.handle_message(station_id, wrapped_msgs, colliding_blob)
    
    accepted = result["status"] == "Accepted"
    reason = result["reason"]
    
    return ScenarioResult(mode, accepted, reason)
