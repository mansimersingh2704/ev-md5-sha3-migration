from enum import Enum
from typing import Any

from app.crypto.canonical import canonicalize_json
from app.crypto.hashing import compute_hmac_sha3_256, compute_sha3_256, verify_hmac


class WrapperMode(str, Enum):
    LEGACY_ONLY = "LEGACY_ONLY"
    DUAL = "DUAL"
    SHA3_ENFORCED = "SHA3_ENFORCED"

class DowngradeError(Exception):
    pass

class ValidationError(Exception):
    pass

def wrap_message(
    msg: list[Any],
    mode: WrapperMode,
    station_id: str,
    key: str | None = None,
    nonce: str = "nonce123",
    timestamp: str = "2026-01-01T00:00:00Z",
    use_sidecar: bool = False,
    blob_hash: str | None = None
) -> list[list[Any]]:
    """
    Wraps an outgoing OCPP message.
    Returns a list of messages (original modified, or original + sidecar).
    """
    if mode == WrapperMode.LEGACY_ONLY:
        return [msg]
    
    import copy
    
    # We only wrap CALL messages for simplicity in this demo, or specific ones.
    if msg[0] != 2:
        return [msg]
        
    unique_id = msg[1]
    action = msg[2]
    payload = copy.deepcopy(msg[3]) # Deep copy payload
    
    sha3_digest = blob_hash if blob_hash else compute_sha3_256(canonicalize_json(payload))
    hmac_digest = None
    if key:
        hmac_digest = compute_hmac_sha3_256(key, station_id, action, unique_id, payload, nonce, timestamp)

    if use_sidecar:
        # Create a sidecar DataTransfer message
        data_dict: dict[str, str] = {
            "referenceId": str(unique_id),
            "sha3_256": sha3_digest,
            "nonce": nonce,
            "timestamp": timestamp
        }
        if hmac_digest:
            data_dict["hmac_sha3_256"] = hmac_digest
            
        sidecar_payload: dict[str, Any] = {
            "vendorId": "ChargeShield",
            "messageId": "IntegrityAttestation",
            "data": data_dict
        }
        
        sidecar_msg = [2, f"{unique_id}_attest", "DataTransfer", sidecar_payload]
        return [msg, sidecar_msg]
    else:
        # In-band sibling keys
        if "metadata" in payload and isinstance(payload["metadata"], dict):
            payload["metadata"]["sha3_256"] = sha3_digest
            payload["metadata"]["nonce"] = nonce
            payload["metadata"]["timestamp"] = timestamp
            if hmac_digest:
                payload["metadata"]["hmac_sha3_256"] = hmac_digest
        elif "data" in payload and isinstance(payload["data"], dict) and payload.get("vendorId") == "ChargeShield_Legacy":
            payload["data"]["sha3_256"] = sha3_digest
            payload["data"]["nonce"] = nonce
            payload["data"]["timestamp"] = timestamp
            if hmac_digest:
                payload["data"]["hmac_sha3_256"] = hmac_digest
                
        wrapped_msg = [msg[0], msg[1], msg[2], payload]
        return [wrapped_msg]

def unwrap_and_verify(
    msg: list[Any],
    mode: WrapperMode,
    station_id: str,
    key: str | None = None,
    sidecar_msg: list[Any] | None = None
) -> tuple[list[Any], str | None]:
    """
    Unwraps and verifies an incoming message.
    Blocks downgrade attacks in SHA3_ENFORCED mode.
    Returns the cleaned message for the legacy parser, and the extracted sha3 digest if present.
    """
    if msg[0] != 2:
        return msg, None
        
    import copy
    unique_id = msg[1]
    action = msg[2]
    payload = copy.deepcopy(msg[3])
    
    has_sha3 = False
    has_hmac = False
    valid_hmac = False
    extracted_sha3 = None
    
    # Check sidecar first
    if sidecar_msg and sidecar_msg[0] == 2 and sidecar_msg[2] == "DataTransfer":
        sc_payload = sidecar_msg[3]
        if sc_payload.get("vendorId") == "ChargeShield" and sc_payload.get("messageId") == "IntegrityAttestation":
            data = sc_payload.get("data", {})
            if data.get("referenceId") == unique_id:
                has_sha3 = "sha3_256" in data
                if has_sha3: extracted_sha3 = data["sha3_256"]
                has_hmac = "hmac_sha3_256" in data
                
                if has_hmac and key:
                    valid_hmac = verify_hmac(
                        data["hmac_sha3_256"], key, station_id, action, unique_id, payload,
                        data.get("nonce", ""), data.get("timestamp", "")
                    )
    
    # Check in-band
    if not has_sha3:
        if "metadata" in payload and isinstance(payload["metadata"], dict):
            meta = payload["metadata"]
            if "sha3_256" in meta:
                has_sha3 = True
                extracted_sha3 = meta["sha3_256"]
                if "hmac_sha3_256" in meta:
                    has_hmac = True
                    if key:
                        valid_hmac = verify_hmac(
                            meta["hmac_sha3_256"], key, station_id, action, unique_id, 
                            {**payload, "metadata": {k: v for k, v in meta.items() if k not in ["sha3_256", "hmac_sha3_256", "nonce", "timestamp"]}},
                            meta.get("nonce", ""), meta.get("timestamp", "")
                        )
                # Strip out wrapper fields for legacy parser
                cleaned_meta = {k: v for k, v in meta.items() if k not in ["sha3_256", "hmac_sha3_256", "nonce", "timestamp"]}
                payload["metadata"] = cleaned_meta

        elif "data" in payload and isinstance(payload["data"], dict) and payload.get("vendorId") == "ChargeShield_Legacy":
            data = payload["data"]
            if "sha3_256" in data:
                has_sha3 = True
                extracted_sha3 = data["sha3_256"]
                if "hmac_sha3_256" in data:
                    has_hmac = True
                    if key:
                        # For HMAC verification of in-band, the canonical payload must not include the injected fields.
                        cleaned_data = {k: v for k, v in data.items() if k not in ["sha3_256", "hmac_sha3_256", "nonce", "timestamp"]}
                        test_payload = {**payload, "data": cleaned_data}
                        valid_hmac = verify_hmac(
                            data["hmac_sha3_256"], key, station_id, action, unique_id, test_payload,
                            data.get("nonce", ""), data.get("timestamp", "")
                        )
                cleaned_data = {k: v for k, v in data.items() if k not in ["sha3_256", "hmac_sha3_256", "nonce", "timestamp"]}
                payload["data"] = cleaned_data

    if mode == WrapperMode.SHA3_ENFORCED:
        if not has_sha3:
            raise DowngradeError("Downgrade attack detected: SHA-3 digest missing in SHA3_ENFORCED mode.")
        if not has_hmac:
            raise DowngradeError("Downgrade attack detected: HMAC missing in SHA3_ENFORCED mode.")
        if not valid_hmac:
            raise ValidationError("HMAC verification failed.")
            
    return [msg[0], msg[1], msg[2], payload], extracted_sha3
