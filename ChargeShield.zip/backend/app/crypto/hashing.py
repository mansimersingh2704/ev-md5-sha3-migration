import hashlib
import hmac
from typing import Any

from app.crypto.canonical import canonicalize_json


def compute_sha3_256(data: bytes) -> str:
    """Computes SHA-3 256 hash of raw bytes."""
    return hashlib.sha3_256(data).hexdigest()

def compute_firmware_hash(firmware_blob: bytes) -> str:
    """Hashes a firmware blob using SHA-3 256."""
    return compute_sha3_256(firmware_blob)

def compute_hmac_sha3_256(
    key: str,
    station_id: str,
    action: str,
    unique_id: str,
    payload: Any,
    nonce: str,
    timestamp: str
) -> str:
    """
    Computes HMAC-SHA3-256 over:
    stationId | action | uniqueId | canonical_payload | nonce | timestamp
    """
    canonical_payload = canonicalize_json(payload)
    message_parts = [
        station_id.encode('utf-8'),
        action.encode('utf-8'),
        unique_id.encode('utf-8'),
        canonical_payload,
        nonce.encode('utf-8'),
        timestamp.encode('utf-8')
    ]
    message = b'|'.join(message_parts)
    key_bytes = key.encode('utf-8')
    
    h = hmac.new(key_bytes, message, hashlib.sha3_256)
    return h.hexdigest()

def verify_hmac(
    expected_hmac: str,
    key: str,
    station_id: str,
    action: str,
    unique_id: str,
    payload: Any,
    nonce: str,
    timestamp: str
) -> bool:
    """Verifies HMAC-SHA3-256 using constant-time comparison."""
    computed = compute_hmac_sha3_256(
        key=key,
        station_id=station_id,
        action=action,
        unique_id=unique_id,
        payload=payload,
        nonce=nonce,
        timestamp=timestamp
    )
    return hmac.compare_digest(expected_hmac, computed)
