import json
from typing import Any


def canonicalize_json(data: Any) -> bytes:
    """
    Serializes data to canonical JSON rules:
    - Sorted keys
    - No extra whitespace
    - UTF-8 encoded
    """
    return json.dumps(
        data,
        ensure_ascii=False,
        allow_nan=False,
        sort_keys=True,
        separators=(',', ':')
    ).encode('utf-8')
