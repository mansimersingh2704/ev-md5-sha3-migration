import time
import hashlib
import statistics
from typing import Any

def run_benchmarks(payload_size_kb: int = 10, iterations: int = 1000) -> list[dict[str, Any]]:
    payload = b"A" * (payload_size_kb * 1024)
    results = []
    
    algorithms = [
        ("MD5", hashlib.md5),
        ("SHA-1", hashlib.sha1),
        ("SHA-256", hashlib.sha256),
        ("SHA3-256", hashlib.sha3_256)
    ]
    
    for name, func in algorithms:
        times = []
        for _ in range(iterations):
            start = time.perf_counter()
            func(payload).digest()
            end = time.perf_counter()
            times.append((end - start) * 1000)  # ms
        
        avg_time = statistics.mean(times)
        throughput = (payload_size_kb * iterations) / sum(times) * 1000  # KB/s
        
        results.append({
            "algorithm": name,
            "latency_ms": round(avg_time, 4),
            "throughput_kb_s": round(throughput, 2)
        })
        
    return results
