import pytest
from hypothesis import given, strategies as st
from app.crypto.canonical import canonicalize_json
from app.crypto.hashing import compute_sha3_256, compute_hmac_sha3_256, verify_hmac

def test_canonicalize_json():
    data1 = {"b": 2, "a": 1, "c": {"z": 9, "x": 8}}
    data2 = {"a": 1, "c": {"x": 8, "z": 9}, "b": 2}
    
    assert canonicalize_json(data1) == canonicalize_json(data2)
    assert b" " not in canonicalize_json(data1)

@given(st.text(), st.text(), st.text(), st.text(), st.dictionaries(st.text(), st.text()), st.text(), st.text())
def test_hmac_roundtrip(key, station_id, action, unique_id, payload, nonce, timestamp):
    hmac_val = compute_hmac_sha3_256(key, station_id, action, unique_id, payload, nonce, timestamp)
    assert verify_hmac(hmac_val, key, station_id, action, unique_id, payload, nonce, timestamp) is True

def test_hmac_tamper():
    key = "secret"
    payload = {"data": "test"}
    hmac_val = compute_hmac_sha3_256(key, "st1", "Act", "123", payload, "n1", "t1")
    
    # Tamper payload
    tampered_payload = {"data": "tampered"}
    assert verify_hmac(hmac_val, key, "st1", "Act", "123", tampered_payload, "n1", "t1") is False
