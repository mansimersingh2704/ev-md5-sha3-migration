import pytest
from fastapi.testclient import TestClient
from app.main import app
from app.db import Base, engine, get_db
from sqlalchemy.orm import sessionmaker
import os
from app.core.security import get_password_hash
from app.models import User

# Use a test database
SQLALCHEMY_DATABASE_URL = "sqlite:///./test.db"
engine_test = engine

TestingSessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine_test)

def override_get_db():
    try:
        db = TestingSessionLocal()
        yield db
    finally:
        db.close()

app.dependency_overrides[get_db] = override_get_db

@pytest.fixture(scope="module")
def client():
    # Create tables
    Base.metadata.create_all(bind=engine_test)
    
    # Add a test user
    db = TestingSessionLocal()
    user = db.query(User).filter_by(username="testuser").first()
    if not user:
        db.add(User(username="testuser", hashed_password=get_password_hash("testpass")))
        db.commit()
    db.close()
    
    with TestClient(app) as c:
        yield c
        
    Base.metadata.drop_all(bind=engine_test)

def test_health(client):
    res = client.get("/health")
    assert res.status_code == 200

def test_login(client):
    res = client.post("/auth/login", data={"username": "testuser", "password": "testpass"})
    assert res.status_code == 200
    assert "access_token" in res.json()

def test_login_fail(client):
    res = client.post("/auth/login", data={"username": "testuser", "password": "wrong"})
    assert res.status_code == 400

def test_stations_crud(client):
    token = client.post("/auth/login", data={"username": "testuser", "password": "testpass"}).json()["access_token"]
    headers = {"Authorization": f"Bearer {token}"}
    
    res = client.post("/stations", json={"station_id": "ST1", "key": "secret", "mode": "SHA3_ENFORCED"}, headers=headers)
    assert res.status_code == 200
    assert res.json()["status"] == "ok"
    
    res = client.get("/stations", headers=headers)
    assert res.status_code == 200
    stations = res.json()
    assert len(stations) >= 1
    assert any(s["station_id"] == "ST1" for s in stations)

def test_audit_logs(client):
    token = client.post("/auth/login", data={"username": "testuser", "password": "testpass"}).json()["access_token"]
    headers = {"Authorization": f"Bearer {token}"}
    
    res = client.get("/audit/logs", headers=headers)
    assert res.status_code == 200
    logs = res.json()
    assert len(logs) >= 1
    # Check chaining
    for i in range(1, len(logs)):
        assert logs[i]["previous_hash"] == logs[i-1]["hash"]

def test_benchmarks_run(client):
    token = client.post("/auth/login", data={"username": "testuser", "password": "testpass"}).json()["access_token"]
    
    response = client.post("/benchmarks/run", headers={"Authorization": f"Bearer {token}"})
    assert response.status_code == 200
    data = response.json()
    assert len(data) == 4
    assert data[0]["algorithm"] == "MD5"

def test_reports_export(client):
    token = client.post("/auth/login", data={"username": "testuser", "password": "testpass"}).json()["access_token"]
    
    response = client.get("/reports/export", headers={"Authorization": f"Bearer {token}"})
    assert response.status_code == 200
    assert "logs" in response.json()
