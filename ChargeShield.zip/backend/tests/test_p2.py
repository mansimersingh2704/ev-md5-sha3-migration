import pytest
import hashlib
from app.simulator.cp import ChargePoint
from app.simulator.csms import CSMS
from app.simulator.scenario import run_firmware_substitution_scenario
from app.wrapper.proxy import WrapperMode
from app.collision.risk import calculate_risk
from app.collision.loader import load_fixtures
import os
from app.legacy_frozen.parser import parse_legacy_message, get_md5_from_legacy

def test_cp_csms_integration():
    cp = ChargePoint("CP1", "key123", WrapperMode.SHA3_ENFORCED)
    csms = CSMS()
    csms.register_station("CP1", "key123", WrapperMode.SHA3_ENFORCED)
    
    blob = b"firmware_data"
    msgs = cp.create_firmware_update_req(blob)
    
    result = csms.handle_message("CP1", msgs, blob)
    assert result["status"] == "Accepted", result["reason"]
    
def test_cp_data_transfer():
    cp = ChargePoint("CP1", "key123", WrapperMode.DUAL)
    csms = CSMS()
    csms.register_station("CP1", "key123", WrapperMode.DUAL)
    
    blob = b"telemetry_data"
    msgs = cp.create_data_transfer_req(blob)
    result = csms.handle_message("CP1", msgs, blob)
    assert result["status"] == "Accepted", result["reason"]

def test_firmware_substitution_scenario(monkeypatch):
    benign_blob = b"benign"
    colliding_blob = b"malicious"
    
    # Mock MD5 to return the same hash for both blobs
    original_md5 = hashlib.md5
    def mock_md5(data):
        class Dummy:
            def hexdigest(self): return "colliding_md5"
        return Dummy()
    monkeypatch.setattr(hashlib, "md5", mock_md5)
    
    # LEGACY_ONLY accepts the colliding blob because MD5 matches
    r_legacy = run_firmware_substitution_scenario(WrapperMode.LEGACY_ONLY, benign_blob, colliding_blob)
    assert r_legacy.accepted is True
    
    # DUAL mode rejects the colliding blob because SHA3 mismatched
    r_dual = run_firmware_substitution_scenario(WrapperMode.DUAL, benign_blob, colliding_blob)
    assert r_dual.accepted is False
    assert r_dual.reason == "Collision Detected by SHA-3"
    
    # SHA3_ENFORCED mode rejects
    r_enforced = run_firmware_substitution_scenario(WrapperMode.SHA3_ENFORCED, benign_blob, colliding_blob)
    assert r_enforced.accepted is False
    assert r_enforced.reason == "Collision Detected by SHA-3"

def test_risk_scoring_all_paths():
    assert calculate_risk("UpdateFirmware", "LEGACY_ONLY").score == 90.0
    assert calculate_risk("UpdateFirmware", "DUAL").score == 40.0
    assert calculate_risk("UpdateFirmware", "SHA3_ENFORCED").score == 10.0
    assert calculate_risk("DataTransfer", "LEGACY_ONLY").score == 48.0
    assert calculate_risk("DataTransfer", "DUAL").score == 18.0
    assert calculate_risk("DataTransfer", "SHA3_ENFORCED").score == 6.0
    assert calculate_risk("BootNotification", "LEGACY_ONLY").score == 2.0

def test_loader_paths(tmp_path):
    d = tmp_path / "fixtures"
    d.mkdir()
    # Write a valid fake pair that won't actually be identical but we can test the MD5 mismatch failure path
    f1 = d / "identical1.bin"
    f2 = d / "identical2.bin"
    f1.write_bytes(b"a")
    f2.write_bytes(b"b")
    loaded = load_fixtures(str(d))
    assert len(loaded) == 0 # skips because MD5 mismatch

def test_parser_helpers():
    assert get_md5_from_legacy({"metadata": {"md5Checksum": "123"}}) == "123"
    assert get_md5_from_legacy({"data": {"md5Checksum": "456"}}) == "456"
    assert get_md5_from_legacy({}) is None
    
def test_csms_unregistered_station():
    csms = CSMS()
    assert csms.handle_message("unknown", [], b"")["status"] == "Rejected"
