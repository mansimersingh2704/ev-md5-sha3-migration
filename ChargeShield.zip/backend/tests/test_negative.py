import pytest
import copy
from app.crypto.canonical import canonicalize_json
from app.crypto.hashing import compute_hmac_sha3_256, verify_hmac
from app.wrapper.proxy import wrap_message, unwrap_and_verify, WrapperMode, DowngradeError, ValidationError

def test_canonical_json_edge_cases():
    # Key order
    assert canonicalize_json({"a": 1, "b": 2}) == canonicalize_json({"b": 2, "a": 1})
    
    # Unicode
    assert canonicalize_json({"k": "vü"}) == b'{"k":"v\xc3\xbc"}'
    
    # Floats (standardized to no trailing spaces)
    assert canonicalize_json({"f": 1.0}) == b'{"f":1.0}'
    
    # Nested arrays
    assert canonicalize_json({"arr": [3, 1, 2]}) == b'{"arr":[3,1,2]}'
    # Arrays are NOT sorted
    assert canonicalize_json({"arr": [3, 1, 2]}) != canonicalize_json({"arr": [1, 2, 3]})

def test_hmac_wrong_station_key():
    hmac_val = compute_hmac_sha3_256("key1", "st1", "Act", "1", {}, "nonce", "ts")
    assert verify_hmac(hmac_val, "key2", "st1", "Act", "1", {}, "nonce", "ts") is False

def test_hmac_tampered():
    hmac_val = compute_hmac_sha3_256("key1", "st1", "Act", "1", {"k":"v"}, "nonce", "ts")
    assert verify_hmac(hmac_val, "key1", "st1", "Act", "1", {"k":"v2"}, "nonce", "ts") is False

def test_wrapper_downgrade():
    msg = [2, "123", "UpdateFirmware", {"metadata": {"md5Checksum": "abc"}}]
    # Missing SHA-3 extension
    with pytest.raises(DowngradeError):
        unwrap_and_verify(msg, WrapperMode.SHA3_ENFORCED, "station1", "key")

def test_wrapper_missing_extension():
    msg = [2, "123", "UpdateFirmware", {"metadata": {"md5Checksum": "abc"}}]
    # Just missing entirely under enforced mode
    with pytest.raises(DowngradeError):
        unwrap_and_verify(msg, WrapperMode.SHA3_ENFORCED, "station1", "key")

def test_wrapper_wrong_key_validation_error():
    msg = [2, "123", "UpdateFirmware", {"metadata": {"md5Checksum": "abc"}}]
    wrapped = wrap_message(copy.deepcopy(msg), WrapperMode.SHA3_ENFORCED, "station1", "key1")
    
    with pytest.raises(ValidationError):
        unwrap_and_verify(wrapped[0], WrapperMode.SHA3_ENFORCED, "station1", "key2")

# Replay / Nonce reuse
# In a real system, the server tracks seen nonces/timestamps.
# Here we just verify they are part of the HMAC input and changing them breaks it.
def test_hmac_replay_prevention():
    hmac_val = compute_hmac_sha3_256("key1", "st1", "Act", "1", {}, "nonce1", "ts1")
    # If attacker resends with new nonce/timestamp to bypass replay filter, HMAC fails
    assert verify_hmac(hmac_val, "key1", "st1", "Act", "1", {}, "nonce2", "ts1") is False
    assert verify_hmac(hmac_val, "key1", "st1", "Act", "1", {}, "nonce1", "ts2") is False
