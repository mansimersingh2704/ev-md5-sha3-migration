import pytest
import json
from app.legacy_frozen.parser import parse_legacy_message, LegacyParserError
from app.wrapper.proxy import wrap_message, WrapperMode

def test_tolerant_mode_accepts_inband():
    # Tolerant mode ignores extra fields like sha3_256 in the payload
    msg = [2, "123", "UpdateFirmware", {"metadata": {"md5Checksum": "abc"}}]
    wrapped = wrap_message(msg, WrapperMode.SHA3_ENFORCED, "station1", "key")[0]
    
    parsed = parse_legacy_message(json.dumps(wrapped), strict=False)
    assert parsed["msg_type"] == 2

def test_strict_mode_rejects_inband():
    # Strict mode validates allowed keys exactly.
    msg = [2, "123", "UpdateFirmware", {"metadata": {"md5Checksum": "abc", "sha3_256": "def"}}]
    with pytest.raises(LegacyParserError, match="Strict validation failed: unknown fields"):
        parse_legacy_message(json.dumps(msg), strict=True)

def test_strict_mode_accepts_sidecar():
    # Sidecar doesn't mutate the original message
    msg = [2, "123", "UpdateFirmware", {"location": "x", "retries": 1, "retrieveDate": "y", "retryInterval": 1, "metadata": {"md5Checksum": "abc"}}]
    wrapped = wrap_message(msg, WrapperMode.SHA3_ENFORCED, "station1", "key", use_sidecar=True)
    
    original_msg = wrapped[0]
    sidecar_msg = wrapped[1]
    
    # Original message passes strict validation (no extra fields added)
    parsed_orig = parse_legacy_message(json.dumps(original_msg), strict=True)
    assert parsed_orig["msg_type"] == 2
    
    # Sidecar message passes strict validation (it's a DataTransfer with vendorId, messageId, data)
    parsed_sidecar = parse_legacy_message(json.dumps(sidecar_msg), strict=True)
    assert parsed_sidecar["msg_type"] == 2
