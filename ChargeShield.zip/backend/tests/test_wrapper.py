import pytest
import json
from hypothesis import given, strategies as st
from app.wrapper.proxy import wrap_message, unwrap_and_verify, WrapperMode, DowngradeError, ValidationError
from app.legacy_frozen.parser import parse_legacy_message
import copy

def test_wrapper_inband_roundtrip():
    msg = [2, "123", "UpdateFirmware", {"metadata": {"md5Checksum": "abc"}}]
    key = "secret_key"
    
    wrapped = wrap_message(copy.deepcopy(msg), WrapperMode.SHA3_ENFORCED, "station1", key)
    assert len(wrapped) == 1
    assert "sha3_256" in wrapped[0][3]["metadata"]
    assert "hmac_sha3_256" in wrapped[0][3]["metadata"]
    
    unwrapped, _ = unwrap_and_verify(wrapped[0], WrapperMode.SHA3_ENFORCED, "station1", key)
    assert unwrapped == msg

    # Legacy parser test (tolerant mode)
    parsed = parse_legacy_message(json.dumps(wrapped[0]), strict=False)
    assert parsed["msg_type"] == 2

def test_wrapper_inband_no_key():
    msg = [2, "123", "UpdateFirmware", {"metadata": {"md5Checksum": "abc"}}]
    
    wrapped = wrap_message(copy.deepcopy(msg), WrapperMode.DUAL, "station1")
    assert "sha3_256" in wrapped[0][3]["metadata"]
    assert "hmac_sha3_256" not in wrapped[0][3]["metadata"]
    
    unwrapped, _ = unwrap_and_verify(wrapped[0], WrapperMode.DUAL, "station1")
    assert unwrapped == msg

def test_wrapper_inband_data_transfer():
    msg = [2, "123", "DataTransfer", {"vendorId": "ChargeShield_Legacy", "data": {"md5Checksum": "abc"}}]
    key = "secret"
    
    wrapped = wrap_message(copy.deepcopy(msg), WrapperMode.SHA3_ENFORCED, "station1", key)
    assert "sha3_256" in wrapped[0][3]["data"]
    
    unwrapped, _ = unwrap_and_verify(wrapped[0], WrapperMode.SHA3_ENFORCED, "station1", key)
    assert unwrapped == msg

def test_wrapper_sidecar_roundtrip():
    msg = [2, "123", "UpdateFirmware", {"location": "http://x", "retries": 3, "retrieveDate": "2026", "retryInterval": 1, "metadata": {"md5Checksum": "abc"}}]
    key = "secret_key"
    
    wrapped = wrap_message(copy.deepcopy(msg), WrapperMode.SHA3_ENFORCED, "station1", key, use_sidecar=True)
    assert len(wrapped) == 2
    
    unwrapped, _ = unwrap_and_verify(wrapped[0], WrapperMode.SHA3_ENFORCED, "station1", key, sidecar_msg=wrapped[1])
    assert unwrapped == msg

    # Legacy parser test (strict mode) - only the original message is sent to the parser
    parsed = parse_legacy_message(json.dumps(wrapped[0]), strict=True)
    assert parsed["msg_type"] == 2

def test_downgrade_protection():
    msg = [2, "123", "UpdateFirmware", {"metadata": {"md5Checksum": "abc"}}]
    key = "secret_key"
    
    # Missing SHA3 and HMAC
    with pytest.raises(DowngradeError):
        unwrap_and_verify(copy.deepcopy(msg), WrapperMode.SHA3_ENFORCED, "station1", key)

def test_legacy_only_mode():
    msg = [2, "123", "UpdateFirmware", {"metadata": {"md5Checksum": "abc"}}]
    wrapped = wrap_message(copy.deepcopy(msg), WrapperMode.LEGACY_ONLY, "station1")
    assert wrapped == [msg]
    unwrapped, _ = unwrap_and_verify(wrapped[0], WrapperMode.LEGACY_ONLY, "station1")
    assert unwrapped == msg

def test_hmac_failure():
    msg = [2, "123", "UpdateFirmware", {"metadata": {"md5Checksum": "abc"}}]
    key = "secret_key"
    wrapped = wrap_message(copy.deepcopy(msg), WrapperMode.SHA3_ENFORCED, "station1", key)
    
    # modify hmac
    wrapped[0][3]["metadata"]["hmac_sha3_256"] = "badhmac"
    
    with pytest.raises(ValidationError):
        unwrap_and_verify(wrapped[0], WrapperMode.SHA3_ENFORCED, "station1", key)

def test_non_call_message():
    msg = [3, "123", {"status": "Accepted"}]
    wrapped = wrap_message(copy.deepcopy(msg), WrapperMode.DUAL, "station1")
    assert wrapped == [msg]
    unwrapped, _ = unwrap_and_verify(wrapped[0], WrapperMode.DUAL, "station1")
    assert unwrapped == msg
