# ChargeShield Architecture and Plan

## Architecture & Folder Tree
ChargeShield is a full-stack platform consisting of a Python FastAPI backend and a React (Vite) frontend.

```text
c:\Users\acer\OneDrive\Desktop\crypto project
├── backend/
│   ├── alembic/
│   ├── app/
│   │   ├── api/          # API routers (endpoints)
│   │   ├── core/         # Config, security, logging
│   │   ├── crypto/       # SHA-3 wrapper, hashing functions, risk scoring
│   │   ├── models/       # SQLAlchemy models
│   │   ├── schemas/      # Pydantic validation schemas
│   │   ├── services/     # Business logic, migration planner, benchmarks
│   │   ├── simulator/    # Local OCPP 1.6J simulated charge point + CSMS
│   │   ├── wrapper/      # SHA-3 compatibility proxy and attestation handling
│   │   ├── legacy_frozen/# Unmodifiable MD5 parsing logic
│   │   └── main.py       # FastAPI entrypoint
│   ├── tests/            # pytest and hypothesis test suites
│   └── requirements.txt
├── frontend/
│   ├── src/
│   │   ├── components/   # React components, Radix UI primitives
│   │   ├── hooks/        # Custom React hooks (TanStack Query)
│   │   ├── lib/          # Utils, CSS token definitions, api client
│   │   ├── routes/       # TanStack Router route components
│   │   ├── App.tsx
│   │   ├── index.css     # Tailwind CSS v4 token definitions
│   │   └── main.tsx
│   ├── tests/
│   │   └── e2e/          # Playwright tests
│   ├── package.json
│   ├── tsconfig.json
│   ├── vercel.json
│   └── vite.config.ts
├── docs/
│   ├── architecture/
│   ├── engineering/
│   ├── product/
│   ├── research/
│   └── screenshots/
├── tasks/
│   ├── CURRENT_TASK.md
│   ├── CONVERGENCE_TEMPLATE.md
│   ├── P1_task.md
│   ├── P2_task.md
│   ├── P3_task.md
│   ├── P4_task.md
│   ├── P5_task.md
│   └── P6_task.md
├── .github/
│   └── workflows/
│       └── ci.yml        # Including backend/app/legacy_frozen/ lockfile check
├── CODEOWNERS            # Restricting changes to legacy_frozen
├── render.yaml           # Render deployment configuration
├── .env.example
├── AGENTS.md
└── README.md
```

## Legacy Profile Spec
**Definition:** A simulated subset of OCPP 1.6J interactions where MD5 is used for integrity checks. This is EXPLICITLY labeled as [SIMULATED] and not standard OCPP 1.6.

**Fields:**
- `firmwareUpdate`: The `UpdateFirmware.req` message uses a `retrieveDate` and `location`. The payload includes a simulated `metadata` block containing an `md5Checksum` field.
- `dataTransfer`: Custom `DataTransfer.req` messages use an `md5Checksum` in the `data` payload for integrity.
- `securityEvents`: Legacy tokens/events rely on MD5 hashes. (Note: Using MD5 for indexing or deduplication introduces spoofing/collision risks).

**Comparison to OCPP Security Whitepaper:**
The official OCPP security whitepaper's `SignedUpdateFirmware` uses standard asymmetric signatures (ECDSA/RSA) on the firmware itself. Our SHA-3 Compatibility Wrapper is intended strictly as a transitional bridge for resource-constrained legacy embedded devices that cannot adopt the full PKI/asymmetric profiles but require protection against MD5 collision attacks.

## Wrapper Message Format
The SHA-3 Compatibility Wrapper acts as a middleware and guarantees that the `md5Checksum` field is left UNTOUCHED. It operates over two channels:

1. **In-band Sibling Key (Tolerant Schemas):**
   For Legacy Profile vendor-defined blocks (simulated `metadata`, `DataTransfer.data`), the wrapper injects `sha3_256` and `hmac_sha3_256` as sibling keys alongside `md5Checksum`.
   ```json
   {
     "vendorId": "ChargeShield_Legacy",
     "data": {
       "md5Checksum": "legacy_md5_hash",
       "sha3_256": "a3b...f1",
       "hmac_sha3_256": "c8e...a9"
     }
   }
   ```

2. **Sidecar DataTransfer Attestation (Strict Schemas):**
   For strict-schema core OCPP messages, the wrapper issues an immediate trailing `DataTransfer.req` that acts as an attestation referencing the original `uniqueId`.
   ```json
   {
     "vendorId": "ChargeShield",
     "messageId": "IntegrityAttestation",
     "data": {
       "referenceId": "original_message_uniqueId",
       "sha3_256": "a3b...f1",
       "hmac_sha3_256": "c8e...a9"
     }
   }
   ```

**Digest Scope & Canonical JSON:**
- Firmware Hash: Only the raw firmware blob bytes are hashed.
- HMAC Input: `stationId | action | uniqueId | canonical_payload | nonce | timestamp`
- Canonical JSON Rules: Sorted keys, no extra whitespace, UTF-8 encoded. Replay protection is enforced via `nonce` and `timestamp`.

## Threat Model
**Assets:** Firmware updates, DataTransfer payloads.
**Capability Storage:** Capability/migration state is stored server-side and is never derived from message content.

**Attackers & Defenses:**
1. **Supplier-Side Collision Swap:** An attacker generates a malicious firmware blob with the same MD5 hash as the legitimate firmware. A bare SHA-3 digest is sufficient to defend against this, as the MD5-colliding blob will have a different SHA-3 hash.
2. **On-Path Tamper (Man-in-the-Middle):** An on-path attacker modifies the message in transit. A bare SHA-3 digest DOES NOT stop this, as the attacker can recalculate both the MD5 and SHA-3 hashes. Defended ONLY by `SHA3_ENFORCED` requiring HMAC-SHA3-256 with per-station keys.
3. **Downgrade Attack:** An on-path attacker strips the SHA-3 in-band keys or sidecar attestation to force the CSMS to rely on the MD5 hash. `SHA3_ENFORCED` mode consults the server-side state for the station, expects HMAC-SHA3-256, and drops the message if absent.

## API Contract List
- `GET /health` & `GET /ready`
- `POST /api/v1/auth/login` - Returns JWT with roles (admin, analyst, viewer).
- `GET /api/v1/stations` - List stations, capabilities, migration status.
- `POST /api/v1/stations/{id}/mode` - Change wrapper mode (LEGACY_ONLY, DUAL, SHA3_ENFORCED).
- `POST /api/v1/stations/{id}/rollback` - Rollback a station's migration state.
- `POST /api/v1/wrapper/test` - Provide legacy message, return wrapped message and frozen-parser pass/fail.
- `GET /api/v1/collisions/fixtures` - Return MD5 collision test vectors (public identical/chosen prefix).
- `POST /api/v1/benchmarks/run` - Run throughput/latency benchmarks for hash algorithms.
- `GET /api/v1/reports/export` - Export audit logs and findings.
- `GET /api/v1/audit` - View hash-chained audit log.
- `GET /api/v1/alerts` - Active alerts and risk scores.
- `GET /api/v1/events/stream` - SSE event stream for live telemetry.
- `POST /api/v1/simulator/control` - Local simulator control commands.
- `GET /api/v1/risks` - Per-message-type risk scores.

## Phased Task List (tasks/*.md)
- P1: Backend crypto module, frozen legacy parser (tolerant & strict), wrapper (both channels, downgrade protection), hypothesis tests.
- P2: OCPP Simulator, public collision fixtures loading, risk scoring.
- P3: API endpoints, SQLite DB models, authentication, audit log.
- P4: Frontend layout, routing, command center, station management, collision lab UI.
- P5: Benchmarking system, charts, report generation.
- P6: CI/CD (GitHub Actions), CODEOWNERS, deployment configs, docs update.
