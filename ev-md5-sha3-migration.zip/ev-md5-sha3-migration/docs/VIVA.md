# Viva / Academic Q&A

## Cryptography fundamentals

**1. Why is MD5 broken?**
Wang, Feng, Lai & Yu (2004) demonstrated a practical differential
attack that lets an attacker construct two different inputs producing
the same 128-bit MD5 digest, in far less time than the theoretical
2^64 brute-force birthday bound. Later work reduced this to seconds on
ordinary hardware. This means MD5 provides no meaningful collision
resistance against a motivated attacker.

**2. What exactly is an MD5 collision?**
Two distinct inputs, M1 ≠ M2, such that MD5(M1) = MD5(M2). It does not
require either input to be "guessed" — an attacker with the right
technique can *construct* both inputs together to force a match.

**3. Is every MD5 collision an exploit?**
No. A collision is a mathematical property (two inputs, same digest).
Whether it's exploitable depends on context: if a system uses that
digest to decide whether to trust, execute, or accept a message
without any other check, a collision can be leveraged to substitute
malicious content for legitimate content while passing the integrity
check. If the digest is just one signal among several (e.g. combined
with a MAC, signature, or out-of-band verification), a bare collision
alone is not automatically exploitable.

**4. What's the difference between collision resistance and preimage resistance?**
*Collision resistance*: hard to find **any** two inputs M1 ≠ M2 with
the same digest. *Preimage resistance*: given a digest D, hard to find
**any** input M such that hash(M) = D. *Second-preimage resistance*:
given a specific input M1, hard to find a **different** M2 with the
same digest. MD5's collision resistance is broken; its preimage
resistance is comparatively less severely affected but MD5 is still
not recommended for any of these properties in new designs.

**5. Why is SHA-3 different from SHA-2?**
SHA-2 (including SHA-256) uses the Merkle-Damgard construction, the
same family as MD5 and SHA-1. SHA-3 (Keccak) uses a sponge
construction — structurally unrelated. This means an attack that
exploits Merkle-Damgard-specific weaknesses (like length-extension, or
the differential techniques used against MD5/SHA-1) does not
automatically transfer to SHA-3. NIST standardized SHA-3 partly as a
structurally independent hedge in case a future weakness were found in
the SHA-2 family.

**6. Why not directly replace MD5 with SHA-3 everywhere at once?**
Because legacy parsers/firmware may expect a specific message format
and, in some designs, may expect the integrity field to look a certain
way. A "just swap the algorithm" approach can break legacy consumers
that aren't updated at the same time, which for EV charging
infrastructure with long field lifecycles is often infeasible.

**7. How does backward compatibility work in this project?**
The migration wrapper keeps the original `legacy_message` completely
untouched and attaches integrity metadata (`legacy_md5`, `sha3_256`,
`hmac_sha3_256`) alongside it, externally. A legacy parser that only
reads `legacy_message` keeps working unmodified; an upgraded verifier
reads the same wrapper and checks SHA3-256/HMAC-SHA3-256 instead.

**8. Why can't a hash alone authenticate a message?**
A bare hash proves the message matches *some* digest, but anyone can
compute a hash — including an attacker who modifies the message and
recomputes a new (correct) hash over their modified version. Without a
secret involved, there is nothing stopping that substitution. Hashing
alone provides integrity (corruption detection), not authenticity
(proof of origin/non-tampering by an adversary).

**9. What is HMAC?**
Hash-based Message Authentication Code: a construction that combines a
hash function with a secret key, defined (for modern hashes) roughly
as `HMAC(K, m) = H((K' ⊕ opad) || H((K' ⊕ ipad) || m))`. Because the
attacker doesn't know K, they cannot produce a valid HMAC tag for a
modified message, which is what makes HMAC an authenticity primitive
and a bare hash only an integrity primitive.

**10. Why use SHA3-256 specifically (not SHA3-512, SHA-256, etc.)?**
SHA3-256 gives a 256-bit digest, matching common security-level
expectations (128-bit collision resistance under the birthday bound),
while keeping output size and computation cost proportionate to what a
constrained EV-charger-adjacent system would realistically use. It's
paired here with HMAC-SHA3-256 for the authenticity-requiring MODERN
mode.

## OCPP / EV domain

**11. What is OCPP?**
Open Charge Point Protocol — an open standard (from the Open Charge
Alliance) for communication between EV charge points and a central
charge-point management system (CSMS), covering message types like
BootNotification, Heartbeat, StatusNotification, MeterValues,
StartTransaction, and StopTransaction. This project simulates
OCPP 1.6-style message *structures* for realism; it does not implement
the full OCPP 1.6-J WebSocket/JSON-RPC transport or state machine.

**12. Why is legacy compatibility important in this domain specifically?**
EV charge points are physically deployed, often for a decade or more,
sometimes with constrained firmware update pathways. Forcing a
simultaneous fleet-wide protocol change is operationally and
financially costly, and can create safety/availability risk if done
carelessly. An incremental, wrapper-based migration is much more
realistic for this class of industrial/IoT system.

**13. What happens if an attacker modifies both the message and the hash?**
With a bare hash (no secret), the attacker can simply recompute a
correct hash for their modified message — verification would
incorrectly pass. This is exactly why MODERN mode uses HMAC-SHA3-256
instead of a bare SHA3-256 digest: the attacker cannot recompute a
valid HMAC tag without the shared secret, even if they can modify both
the message and the accompanying (now-invalid) tag.

**14. Why shouldn't we use MD5 even if collisions are "rare" in practice?**
Because "rare by accident" and "rare when an attacker deliberately
constructs one" are completely different claims. MD5's weakness is
that an attacker can **deliberately engineer** a collision quickly —
it is not a matter of hoping a collision doesn't randomly occur.

**15. How would this migration work in a real CSMS, beyond this prototype?**
Realistically: (a) deploy the wrapper at the CSMS ingestion boundary
first, defaulting new/updated chargers to HYBRID mode, (b) monitor
which chargers are capable of MODERN/HMAC verification and migrate
them charger-by-charger, (c) set a sunset date for LEGACY-mode
acceptance, (d) provision and rotate per-charger HMAC keys securely
(e.g. at manufacture or via a secure onboarding flow), and (e) add
transport-layer protections (TLS) and replay protection alongside the
integrity upgrade, since integrity alone doesn't solve replay.

**16. What are the limitations of this prototype?**
See `README.md` Section 18 — most notably: the collision demo uses a
truncated MD5 output space rather than a full 128-bit collision; the
OCPP simulator isn't a compliant OCPP 1.6 implementation; the MODERN
mode's HMAC key is a hardcoded demo constant; and there's no replay
protection or transport encryption implemented.

## Deeper / likely follow-ups

**17. Why does the collision demo truncate MD5 instead of using a real 128-bit collision?**
A full 128-bit MD5 collision search, even using the birthday-attack
shortcut, requires on the order of 2^64 hash operations — far beyond
what a laptop can compute live in a classroom demo. Truncating the
compared output to a smaller number of bits (default 24) shrinks the
birthday-bound search space to roughly 2^(bits/2) attempts (a few
thousand, here), while using the exact same underlying MD5 function
and the exact same birthday-attack logic. It's an honest scale-down,
not a different phenomenon.

**18. Why not just hardcode a famous published MD5 collision pair?**
Several real ones exist in the literature, but manually transcribing
raw collision bytes risks a silent transcription error that produces
two inputs that don't actually collide — which would make the
project's flagship demonstration quietly incorrect. The truncated,
locally-computed, independently-reproducible approach avoids that risk
entirely: you can re-hash both outputs yourself and see they match.

**19. Does a truncated-MD5 collision "prove" anything about full MD5?**
It demonstrates the underlying birthday-attack mechanism that also
underlies full MD5 collision attacks, at a scale that's locally
computable. It is explicitly documented as a simplification, not
presented as a full 128-bit collision.

**20. In HYBRID mode, why does verification prefer SHA3-256 over MD5 rather than checking both?**
Checking "both must pass" would mean a message could be rejected by a
stronger check (SHA3-256) yet the system might still be tempted to
"fall back" to the weaker one and accept it anyway if not designed
carefully. This project's design fails closed instead: SHA3-256 is
authoritative whenever present; MD5 is used only as an explicitly
opted-in fallback during a bounded transition window, never silently.

**21. What would happen if the system silently fell back to MD5 whenever SHA3-256 failed?**
That would reintroduce exactly the collision-substitution risk the
migration is meant to close — an attacker could target the weaker
fallback path directly, which is a classic protocol *downgrade
attack*. This project's HYBRID logic explicitly guards against that by
requiring `allow_legacy_fallback=True` and only using MD5 when
SHA3-256 data is entirely absent, not merely when SHA3-256
verification fails.

**22. Is SHA3-256 vulnerable to length-extension attacks like naive SHA-256 usage can be?**
No — SHA-3's sponge construction is not susceptible to the classic
length-extension attack that affects naive (unsalted, unkeyed)
Merkle-Damgard hash usage. This is one of SHA-3's structural
advantages.

**23. Why include SHA-1 and SHA-256 in the comparison module at all if the project is about MD5→SHA-3?**
To show the full historical progression and let a reader see, side by
side, digest sizes, execution time, and (crucially) that "broken",
"deprecated", and "currently secure" are three different statuses —
not just "old algorithm bad, new algorithm good" without justification.

**24. What does "canonical serialization" mean and why does it matter here?**
Converting a message dict to bytes deterministically (sorted keys,
compact separators) before hashing, so that two logically-identical
messages always serialize to the same bytes and thus the same digest.
Without this, an integrity check could fail purely due to
serialization differences — a correctness bug, not itself a security
fix, but important for the integrity checks to behave predictably.

**25. Why constant-time comparison for MD5 verification in `md5_legacy.py`?**
To avoid a trivial timing side-channel where an attacker could infer
how many leading characters of a guessed digest are correct based on
comparison time — a good defensive habit to demonstrate even though
MD5's core weakness (collision resistance) is the primary issue here.

**26. What's stored in the SQLite database, and why?**
`messages` (every generated/verified/tampered message plus its
digests and verification outcome) and `migration_events` /
`collision_demo_events` (a log of migration-mode changes and collision
demo runs), so the dashboard's Overview tab and the demo walkthrough
have real, persisted evidence of what happened during a session.

**27. Why FastAPI specifically?**
Automatic OpenAPI/Swagger documentation (`/docs`), strong typing via
Pydantic request/response models, and straightforward dependency
injection for the SQLite session — all of which make the API
self-documenting and easy to test via `TestClient`.

**28. How is testing structured?**
Pure-logic tests (crypto primitives, migration wrapper, simulator,
collision fixture) that need no web framework, plus API-level tests
using FastAPI's `TestClient` against an isolated in-memory SQLite
database per test (see `tests/conftest.py`), so tests never touch the
real `data/ev_lab.db`.

**29. What would you change if this had to run at real EV-charging fleet scale?**
Move from SQLite to a proper production database with concurrent
write support, add authentication/authorization on the API, add
replay protection and TLS, integrate real per-charger key
provisioning/rotation (e.g. via a hardware security module or secure
element), and implement OCPP 1.6-J's actual WebSocket/JSON-RPC
transport rather than this project's simplified message structures.

**30. Why does the project explicitly avoid claiming SHA-3 is "simply more secure"?**
Because an unqualified "more secure" claim isn't a real security
argument. The project instead explains *why*: SHA-3's structural
independence from Merkle-Damgard, its resistance to length-extension,
the absence of known practical collision/preimage attacks, and — most
importantly — that a bare hash (SHA-3 included) still isn't
authentication without a MAC. Precision here is itself part of the
demonstrated security understanding.

**31. Can this project's MODERN mode be trivially broken if the HMAC key leaks?**
Yes — HMAC security depends entirely on the secrecy of the key. If the
demo key in `migration.py` (or any production equivalent) leaks, an
attacker can forge valid tags for arbitrary messages. This is
explicitly why the README and code comments flag the hardcoded demo
key as unsuitable for production and call for secure per-charger key
provisioning and rotation as a required next step.
