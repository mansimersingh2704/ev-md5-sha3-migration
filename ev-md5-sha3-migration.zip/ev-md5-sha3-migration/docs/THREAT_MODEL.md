# Threat Model

**Scope:** This threat model covers the *simulated* system implemented
in this repository (a local EV charger simulator, a migration wrapper,
and a local CSMS-side parser/verifier). It also discusses, for
educational completeness, how the same concerns would extend to a real
CSMS deployment — but no part of this repository connects to, scans,
or targets real EV charging infrastructure.

---

## 1. Assets

| Asset | Why it matters |
|---|---|
| EV charging messages (BootNotification, Heartbeat, StatusNotification, etc.) | Drive charge-point state and CSMS decisions |
| Transaction information (StartTransaction / StopTransaction) | Determines billing and session accounting |
| Meter values | Basis for billing accuracy and grid-load reporting |
| Charger identity (`charger_id`) | Used to attribute messages to a specific physical device |
| CSMS-side integrity of accepted messages | The CSMS's trust that what it stored/acted on matches what was actually sent |

## 2. Threats

### T1 — Message tampering in transit
An attacker (or a faulty link) modifies a message between the charger
and the CSMS. **Modeled by:** `app/simulator/ev_charger.tamper_message`
and the `/messages/tamper` endpoint, which produce a modified payload
while deliberately keeping the *original* integrity metadata, exactly
simulating this threat.

**Control:** Any mode's verification correctly flags a tampered
message as `INVALID`, because the recomputed digest/tag no longer
matches the (unmodified) stored digest/tag.

### T2 — Collision-based substitution
An attacker constructs two different messages, M1 (benign) and M2
(malicious), such that a legacy MD5-based check cannot distinguish
them, then substitutes M2 for M1 after M1 was "approved" under its
MD5. **Modeled by:** `app/crypto/collision_fixture.py`'s truncated-MD5
birthday-attack demo, showing that MD5 (even at reduced output width)
does not guarantee that "matching digest" implies "same message."

**Control:** SHA3-256 (HYBRID) or HMAC-SHA3-256 (MODERN) replace MD5
as the authoritative check; MD5 is explicitly documented as untrusted
for this purpose (`app/crypto/md5_legacy.py` module docstring).

### T3 — Downgrade to legacy verification
A system nominally migrated to HYBRID or MODERN mode is tricked (by
misconfiguration, a missing field, or an attacker deliberately
stripping the SHA3-256/HMAC field) into falling back to MD5-only
verification, silently regaining T2's risk.

**Control:** `verify_wrapped_message` in `app/crypto/migration.py`
**fails closed**: in HYBRID mode, if `sha3_256` is missing, it will
only fall back to MD5 if the caller explicitly passes
`allow_legacy_fallback=True`; otherwise it reports `INVALID` /
`NONE` rather than silently trusting MD5. MODERN mode never computes
or accepts MD5 at all, so there is no fallback path to abuse.

### T4 — Replay of a previously valid message
An attacker (or a bug) re-sends a previously valid, correctly-signed
message (e.g. an old StopTransaction) to cause an unintended
duplicate action.

**Status:** **Not mitigated in this prototype.** Neither the wrapper
nor the verifier includes sequence numbers, nonces, or timestamps
bound into the integrity check in a way that would reject a replay.
This is explicitly listed as a limitation (README Section 18) and a
future improvement (README Section 19: "Replay protection via message
sequence numbers / nonces").

### T5 — Forged messages from an unauthenticated source
An attacker with no legitimate access sends a wholly fabricated
message claiming to be from a real charger.

**Control (partial):** MODERN mode's HMAC-SHA3-256 requires possession
of the shared secret to produce a valid tag, which — if the key is
provisioned securely and per-charger — prevents an attacker without
the key from forging an acceptable message. **Not covered:** this
prototype uses one shared demo key for all messages
(`DEMO_HMAC_KEY` in `app/crypto/migration.py`) rather than
per-charger keys, which is explicitly flagged as unsuitable for
production.

### T6 — Compromised legacy charger
A legitimate charger is compromised (malware, physical tampering) and
sends malicious-but-correctly-signed/hashed messages.

**Status:** **Out of scope for a hashing/integrity-migration project.**
No hash, MAC, or signature scheme can prevent a compromised, otherwise
legitimate sender from producing valid but malicious messages — that
requires device attestation, anomaly detection, or other controls
entirely outside this project's scope. Noted here for completeness
rather than left silently unaddressed.

## 3. Non-Threats / Explicit Non-Goals

To keep the threat model honest about what this project does and does
not claim to solve:

- **Confidentiality** of message contents is not addressed (no
  encryption is implemented; this project is about integrity/
  authenticity, not secrecy).
- **Availability** (DoS resistance) of the CSMS or charger is not
  addressed.
- **Physical security** of the charger hardware is out of scope.

## 4. Security Controls Summary

| Control | Implemented where | Addresses |
|---|---|---|
| SHA3-256 integrity | `app/crypto/sha3.py`, HYBRID mode | T2 (in HYBRID, alongside MD5) |
| HMAC-SHA3-256 authenticity | `app/crypto/sha3.py`, MODERN mode | T2, partially T5 |
| Versioned wrapper (`version: 2`) | `app/crypto/migration.py` | Future-proofing; lets a verifier detect and reject/handle unknown wrapper versions |
| Explicit (non-silent) fallback / fail-closed logic | `verify_wrapped_message` | T3 |
| Event logging (messages, verifications, migration-mode changes, collision-demo runs) | `app/core/logging_config.py`, SQLite `migration_events` / `messages` tables | Forensic visibility into T1–T3 |
| Migration policy (three explicit modes with documented risk trade-offs) | `app/crypto/migration.py::migration_mode_security_summary` | Governs the pace/order of rollout, makes trade-offs explicit rather than implicit |

**Not implemented (future work):** replay protection, per-charger key
provisioning/rotation, transport-layer encryption (TLS), and device
attestation. See README Sections 18–19.
