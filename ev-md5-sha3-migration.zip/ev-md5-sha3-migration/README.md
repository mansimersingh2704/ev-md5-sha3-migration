# EV MD5 → SHA-3 Migration Lab

A local, offline academic prototype demonstrating the security risk of
MD5-based integrity checking in legacy EV charging-station message
formats, and a backward-compatible security wrapper that migrates
verification to SHA-3 (and HMAC-SHA3 for authenticity) without
breaking legacy message parsers.

> **Scope note:** This is a **local simulation only**. It does not
> connect to, scan, or interact with any real EV charging station,
> real CSMS platform, or real OCPP deployment. All "chargers" and
> "CSMS" components are simulated in-process.

---

## 1. Project Overview

Legacy EV charge-point firmware and early charge-point management
system (CSMS) integrations sometimes rely on MD5 for message integrity
checking, because MD5 is cheap to compute on constrained embedded
hardware and was considered adequate when those systems were designed.
MD5 is now cryptographically broken. This project:

1. Simulates a legacy EV charger generating OCPP 1.6-style messages.
2. Implements a legacy MD5 integrity layer exactly as such a system
   might use it.
3. Demonstrates, **locally and verifiably**, the underlying weakness
   that makes MD5 unsuitable for integrity decisions against an
   adversary (a real, re-computable birthday-attack collision against
   a truncated MD5 output space).
4. Designs and implements a **backward-compatible migration wrapper**
   that adds SHA3-256 (and HMAC-SHA3-256) verification alongside the
   untouched legacy message, so old parsers keep working unmodified.
5. Ships a dashboard, a REST API, a SQLite event log, and a full
   pytest suite so the whole thing is demonstrable end-to-end.

## 2. Problem Statement

Given a legacy EV/OCPP-style system that uses MD5 for message
integrity:

- How much real risk does that create?
- Can that risk be demonstrated safely and locally, without attacking
  real infrastructure?
- Can integrity verification be upgraded to a modern primitive
  **without** requiring every legacy parser in the field to be
  rewritten or replaced?

## 3. Motivation

Industrial/IoT/EV-charging fleets have long deployment lifecycles.
Charge points can remain in the field for 10–15+ years, firmware
updates are often difficult, expensive, or require a truck roll, and
uptime/safety requirements make a "replace everything at once"
migration impractical. A realistic migration strategy has to be
**incremental and backward-compatible** — which is exactly what
`app/crypto/migration.py` implements and what this README documents.

## 4. Threat Model (summary — full detail in `docs/THREAT_MODEL.md`)

**Assets:** EV charging messages, transaction/meter data, charger
identity, CSMS-side integrity of what it accepts.

**Threats modeled:** message tampering in transit, collision-based
substitution of a message with different content but a matching MD5,
downgrade to weaker (legacy) verification, and the general risk of
conflating "integrity" with "authenticity."

**Controls implemented:** SHA3-256 integrity, HMAC-SHA3-256
authenticity, a versioned wrapper format, explicit (never silent)
fallback behavior, and event logging of every verification and
migration-mode change.

## 5. Architecture

```
Legacy path (today):

  EV Charger --(legacy OCPP-style message)--> MD5 Integrity Layer --> Legacy CSMS Parser


Migrated path (this project's contribution):

  EV Charger --(legacy-compatible message)--> Migration/Security Wrapper
                                                     |-- MD5 compatibility verification (LEGACY/HYBRID)
                                                     |-- SHA3-256 integrity verification (HYBRID)
                                                     |-- HMAC-SHA3-256 authenticity verification (MODERN)
                                                     v
                                              Legacy CSMS Parser (unmodified — reads legacy_message only)
```

The wrapper format (`app/crypto/migration.py`):

```json
{
  "version": 2,
  "legacy_message": { "...": "untouched OCPP-style message" },
  "legacy_md5": "…or null",
  "sha3_256": "…or null",
  "hmac_sha3_256": "…or null",
  "algorithm": "MD5 | SHA3-256 | HMAC-SHA3-256",
  "migration_mode": "LEGACY | HYBRID | MODERN"
}
```

### Component map

| Layer | Files |
|---|---|
| EV/OCPP simulator | `app/simulator/ev_charger.py` |
| Legacy MD5 module (isolated) | `app/crypto/md5_legacy.py` |
| SHA-1 (comparison only) | `app/crypto/sha1.py` |
| SHA-256 (comparison) | `app/crypto/sha256.py` |
| SHA-3 / HMAC-SHA3 | `app/crypto/sha3.py` |
| Migration wrapper (main contribution) | `app/crypto/migration.py` |
| Collision demonstration | `app/crypto/collision_fixture.py` |
| Hash comparison + benchmark | `app/crypto/comparison.py` |
| Business logic | `app/services/*.py` |
| REST API | `app/api/*.py`, `app/main.py` |
| Persistence | `app/models/db_models.py`, `app/core/db.py` (SQLite) |
| Dashboard | `frontend/index.html`, `style.css`, `app.js` |
| Tests | `tests/*.py` |

## 6. MD5 Vulnerability

MD5 was shown to be practically breakable by Wang, Feng, Lai & Yu
(2004): an attacker can construct two **different** inputs that
produce the **same** MD5 digest (a "collision"). This means an
MD5-based integrity check cannot be trusted to prove that a message
wasn't substituted by an adversary — only that it wasn't *accidentally*
corrupted, in a non-adversarial setting. `app/crypto/md5_legacy.py`
documents this in detail and isolates all MD5 usage into a single,
auditable module.

## 7. Collision Demonstration

**Why this project does not hardcode "the famous" MD5 collision
bytes:** several real, published MD5 collision pairs exist in the
academic literature, but transcribing them from memory risks a silent
error that produces two inputs that don't actually collide — which
would make the flagship demo of a security project quietly wrong.

**What it does instead:** `app/crypto/collision_fixture.py` runs a
**real, local, independently re-verifiable** birthday-attack search
for two different messages whose MD5 digests agree on a **deliberately
truncated** number of bits (default 24). This is a standard, honest
teaching simplification: a full 128-bit MD5 collision needs work far
beyond what a live classroom demo can compute, but shrinking the
output space to `truncate_bits` bits makes the *exact same*
birthday-attack mechanism complete in milliseconds — with genuinely
different inputs and a genuinely equal (truncated) MD5 output, nothing
faked. The demo also computes the full 128-bit MD5 and the SHA3-256 of
both messages, to show the "collision" does not carry over to either.

If you want to extend this project with a genuine, full 128-bit MD5
collision, source published collision-pair files from established
academic cryptanalysis work (e.g. chosen-prefix collision tooling from
the CWI/Eindhoven research group) rather than transcribing bytes by
hand, and load them via a new function alongside
`find_truncated_md5_collision` in `collision_fixture.py`.

## 8. SHA-3 Migration Strategy

Three explicit modes (`app/crypto/migration.py`):

| Mode | What's computed | Guarantee | Risk |
|---|---|---|---|
| `LEGACY` | MD5 only | Corruption detection only | No authenticity; vulnerable to collision-based substitution |
| `HYBRID` | MD5 + SHA3-256 | Strong integrity via SHA3-256, MD5 kept only for a bounded transition window | If fallback is misconfigured to always allow MD5, effective security regresses to LEGACY |
| `MODERN` | HMAC-SHA3-256 only | Authenticated integrity (requires shared secret) | Requires secure key provisioning/rotation |

**No silent downgrades:** in `HYBRID` mode, verification always
prefers SHA3-256. It falls back to MD5 **only** if SHA3-256 data is
absent **and** the caller explicitly passes
`allow_legacy_fallback=True` — otherwise verification fails closed.
`MODERN` mode never has MD5 data to fall back to at all.

## 9. Backward Compatibility Strategy

The wrapper never modifies `legacy_message`. A legacy parser that only
knows how to read `wrapped["legacy_message"]` (or, in `LEGACY` mode,
the message as sent) keeps working completely unmodified after
migration — it never needs to know MD5, SHA-3, or HMAC exist. Upgraded
clients read the same wrapper and get real cryptographic improvement.
This is what makes an incremental, charger-by-charger or
CSMS-side-only migration realistic.

## 10. Hash vs. MAC (Integrity vs. Authentication)

A bare hash — MD5, SHA-256, or even SHA3-256 — only proves that a
message matches *some* digest. It says nothing about *who* produced
that digest. An attacker who can modify a message in transit can
simply recompute a new plain hash over their modified version and
attach that instead, unless the hash is bound to a secret the attacker
doesn't have. **That is what HMAC is for.** `app/crypto/sha3.py`
provides `hmac_sha3_256`, and `MODERN` migration mode uses it — not a
bare SHA3-256 digest — whenever authenticity (not just
corruption-detection) matters. This project never claims that a plain
SHA-3 hash alone provides authenticity.

## 11. API Documentation

FastAPI auto-generates interactive docs at **`/docs`** (Swagger UI)
and **`/redoc`**. Key endpoints:

| Method | Path | Purpose |
|---|---|---|
| POST | `/api/messages` | Generate a simulated EV message, wrapped per migration mode |
| GET | `/api/messages` | List recent messages |
| GET | `/api/messages/{id}` | Get one message |
| POST | `/api/messages/verify` | Verify a stored message's integrity |
| POST | `/api/messages/tamper` | Create a tampered copy of a message and verify it |
| POST | `/api/hash/compare` | Compare MD5/SHA-1/SHA-256/SHA3-256 over text or a stored message |
| GET | `/api/collision-demo` | Run the truncated-MD5 collision demo |
| POST | `/api/migration/verify` | Verify an arbitrary wrapped-message JSON |
| GET | `/api/migration/modes` | List migration modes + security summary |
| POST | `/api/migration/mode` | Set the dashboard's default migration mode |
| GET | `/api/system/status` | System overview counters |

## 12. Installation

Requires Python 3.11+.

```bash
git clone <your-repo-url>
cd ev-md5-sha3-migration
python3 -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

## 13. Running Locally

```bash
uvicorn app.main:app --reload
```

- Dashboard: **http://127.0.0.1:8000/**
- API docs: **http://127.0.0.1:8000/docs**

### With Docker

```bash
docker compose up --build
```

Then open http://127.0.0.1:8000/.

## 14. Testing

```bash
pytest
```

Covers: MD5/SHA-1/SHA-256/SHA3-256 generation, HMAC-SHA3
verification, canonical serialization, tampering detection across all
three migration modes, the collision fixture (including that it's
independently re-verifiable, not hardcoded), malformed-message and
invalid-digest handling, and the full API surface via FastAPI's
`TestClient` against an isolated in-memory SQLite database.

## 15. Demo Walkthrough (5–7 minutes)

1. **Start the app** — `uvicorn app.main:app --reload`, open the dashboard.
2. **Overview tab** — note the counters all start at zero.
3. **EV Simulator tab** — generate a `StartTransaction` message in `HYBRID` mode; show the wrapped JSON (legacy message untouched, MD5 + SHA3-256 attached).
4. **Verify Integrity** — show it returns `VALID`, method `SHA3-256`.
5. **Tamper Message** — show the payload changes but the original digests don't; verify again → `INVALID`.
6. **Collision Demo tab** — run the truncated-MD5 collision search; show two different messages with equal truncated MD5 but different SHA3-256.
7. **Migration Demo tab** — walk through the LEGACY vs. migrated (wrapper) data-flow diagrams and the mode comparison table.
8. **Switch to MODERN mode** in Overview, generate a new message in the Simulator, verify it → method `HMAC-SHA3-256`.
9. **Security Analysis tab** — walk through MD5/SHA-1/SHA-256/SHA-3 and the integrity-vs-authentication explanation.
10. **`/docs`** — show the auto-generated OpenAPI documentation as evidence of a real, working API.

## 16. Explanation of Important Code Files

- **`app/crypto/md5_legacy.py`** — the only place MD5 is computed; heavily commented on why it's broken and how it's contained.
- **`app/crypto/sha3.py`** — SHA3-256 and HMAC-SHA3-256, with the reasoning for why SHA-3's sponge construction matters and why a bare hash isn't authentication.
- **`app/crypto/migration.py`** — the project's main contribution: the versioned, backward-compatible wrapper and the three migration modes with fail-closed, no-silent-downgrade verification logic.
- **`app/crypto/collision_fixture.py`** — the real, local, re-verifiable truncated-MD5 birthday-attack collision demo, with an explicit explanation of why it doesn't hardcode transcribed "famous" collision bytes.
- **`app/simulator/ev_charger.py`** — generates realistic OCPP 1.6-style message structures and simulates message tampering.
- **`app/services/message_service.py`** — orchestrates generate → wrap → store → verify → tamper, and logs every security-relevant event.
- **`app/main.py`** + **`app/api/*.py`** — FastAPI app wiring, routers, and OpenAPI docs.
- **`frontend/app.js`** — talks to the API and renders the dashboard's six sections.

## 17. Likely Viva Questions

See **`docs/VIVA.md`** for 30+ questions with strong answers.

## 18. Limitations

- The collision demo targets a **truncated** MD5 output space (default 24 bits), not the full 128-bit space, for local classroom feasibility — this is explicitly documented, not hidden.
- The OCPP message simulator produces realistic-looking structures but is **not** a compliant OCPP 1.6 implementation (no WebSocket/JSON-RPC framing, no full state machine).
- `MODERN` mode's HMAC key is a hardcoded demo constant (`app/crypto/migration.py`) — clearly commented as unsuitable for production, where it must be securely provisioned per-charger and rotated.
- No replay protection, sequence numbers, or transport-layer encryption are implemented — these are separate controls, listed as future work in `docs/THREAT_MODEL.md`.
- SQLite is used for local, single-instance storage only; not designed for concurrent production use.

## 19. Future Improvements

- Genuine full-length MD5 collision fixture sourced from published academic collision-pair files (see Section 7).
- Real per-charger HMAC key provisioning and rotation.
- Replay protection via message sequence numbers / nonces.
- TLS-based transport layer for the simulated charger-to-CSMS link.
- A proper OCPP 1.6-J (WebSocket/JSON-RPC) transport layer for closer real-world fidelity, still fully local/simulated.
- Role-based access control on the dashboard/API for a multi-user classroom setting.

## 20. References

- Wang, X., Feng, D., Lai, X., & Yu, H. (2004). *Collisions for Hash Functions MD4, MD5, HAVAL-128 and RIPEMD.*
- Stevens, M., Bursztein, E., Karpman, P., Albertini, A., & Markov, Y. (2017). *The first collision for full SHA-1* ("SHAttered").
- NIST FIPS 180-4 — Secure Hash Standard (SHA-1, SHA-2 family).
- NIST FIPS 202 — SHA-3 Standard: Permutation-Based Hash and Extendable-Output Functions.
- NIST FIPS 198-1 — The Keyed-Hash Message Authentication Code (HMAC).
- Open Charge Alliance — OCPP 1.6 specification (referenced conceptually for message-type naming only; not implemented in full).

## Screenshots

_(Add screenshots of the dashboard's six tabs here before submitting/publishing — Overview, Hash Comparison, EV Simulator, Collision Demo, Migration Demo, Security Analysis.)_
