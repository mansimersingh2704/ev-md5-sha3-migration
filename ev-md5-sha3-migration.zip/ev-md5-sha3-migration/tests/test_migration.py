"""Tests for the backward-compatible migration wrapper (app/crypto/migration.py)."""

import copy

import pytest

from app.crypto import migration


SAMPLE_MESSAGE = {
    "message_id": "abc-123",
    "message_type": "StartTransaction",
    "charger_id": "CP-1000",
    "timestamp": "2026-01-01T00:00:00+00:00",
    "payload": {"connectorId": 1, "idTag": "TAG1", "meterStart": 10, "timestamp": "2026-01-01T00:00:00+00:00"},
}


@pytest.mark.parametrize("mode", list(migration.MigrationMode))
def test_wrap_and_verify_roundtrip(mode):
    wrapped = migration.wrap_message(SAMPLE_MESSAGE, mode)
    d = wrapped.to_dict()
    assert d["legacy_message"] == SAMPLE_MESSAGE  # unchanged, legacy-parseable
    result = migration.verify_wrapped_message(d)
    assert result.valid is True
    assert result.migration_mode == mode


def test_legacy_mode_only_has_md5():
    wrapped = migration.wrap_message(SAMPLE_MESSAGE, migration.MigrationMode.LEGACY).to_dict()
    assert wrapped["legacy_md5"] is not None
    assert wrapped["sha3_256"] is None
    assert wrapped["hmac_sha3_256"] is None


def test_hybrid_mode_has_both_md5_and_sha3():
    wrapped = migration.wrap_message(SAMPLE_MESSAGE, migration.MigrationMode.HYBRID).to_dict()
    assert wrapped["legacy_md5"] is not None
    assert wrapped["sha3_256"] is not None
    assert wrapped["hmac_sha3_256"] is None


def test_modern_mode_has_only_hmac_no_md5():
    wrapped = migration.wrap_message(SAMPLE_MESSAGE, migration.MigrationMode.MODERN).to_dict()
    assert wrapped["legacy_md5"] is None
    assert wrapped["sha3_256"] is None
    assert wrapped["hmac_sha3_256"] is not None


def test_hybrid_prefers_sha3_even_if_md5_is_wrong():
    """SHA3-256 should be authoritative in HYBRID mode; a stale/wrong MD5 must not affect the result."""
    wrapped = migration.wrap_message(SAMPLE_MESSAGE, migration.MigrationMode.HYBRID).to_dict()
    wrapped["legacy_md5"] = "0" * 32  # deliberately corrupt the MD5 field
    result = migration.verify_wrapped_message(wrapped)
    assert result.valid is True
    assert result.method_used == migration.VerificationMethod.SHA3_256


def test_hybrid_fails_closed_without_explicit_fallback_when_sha3_missing():
    wrapped = migration.wrap_message(SAMPLE_MESSAGE, migration.MigrationMode.HYBRID).to_dict()
    del wrapped["sha3_256"]
    result = migration.verify_wrapped_message(wrapped, allow_legacy_fallback=False)
    assert result.valid is False
    assert result.method_used == migration.VerificationMethod.NONE


def test_hybrid_allows_md5_fallback_only_when_explicitly_requested():
    wrapped = migration.wrap_message(SAMPLE_MESSAGE, migration.MigrationMode.HYBRID).to_dict()
    del wrapped["sha3_256"]
    result = migration.verify_wrapped_message(wrapped, allow_legacy_fallback=True)
    assert result.valid is True
    assert result.method_used == migration.VerificationMethod.MD5
    assert result.downgraded is True


def test_tampering_detected_in_all_modes():
    for mode in migration.MigrationMode:
        wrapped = migration.wrap_message(SAMPLE_MESSAGE, mode).to_dict()
        tampered = copy.deepcopy(wrapped)
        tampered["legacy_message"]["payload"]["meterStart"] += 999
        result = migration.verify_wrapped_message(tampered)
        assert result.valid is False, f"Tampering should be detected in {mode}"


def test_malformed_wrapper_missing_legacy_message():
    result = migration.verify_wrapped_message({"migration_mode": "HYBRID"})
    assert result.valid is False
    assert result.method_used == migration.VerificationMethod.NONE


def test_unknown_migration_mode_handled_gracefully():
    wrapped = migration.wrap_message(SAMPLE_MESSAGE, migration.MigrationMode.HYBRID).to_dict()
    wrapped["migration_mode"] = "NOT_A_REAL_MODE"
    result = migration.verify_wrapped_message(wrapped)
    assert result.valid is False


def test_modern_mode_rejects_wrong_hmac_key():
    wrapped = migration.wrap_message(SAMPLE_MESSAGE, migration.MigrationMode.MODERN).to_dict()
    result = migration.verify_wrapped_message(wrapped, hmac_key=b"a-completely-different-key")
    assert result.valid is False
