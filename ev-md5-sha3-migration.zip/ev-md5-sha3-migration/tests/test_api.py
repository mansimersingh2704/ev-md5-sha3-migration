"""End-to-end API tests using FastAPI's TestClient against an in-memory DB."""


def test_create_and_get_message(client):
    resp = client.post("/api/messages", json={"message_type": "Heartbeat", "migration_mode": "HYBRID"})
    assert resp.status_code == 200
    body = resp.json()
    assert body["message_type"] == "Heartbeat"
    assert body["migration_mode"] == "HYBRID"
    assert body["wrapped"]["legacy_message"] == body["payload"]

    resp2 = client.get(f"/api/messages/{body['id']}")
    assert resp2.status_code == 200
    assert resp2.json()["id"] == body["id"]


def test_get_nonexistent_message_returns_404(client):
    resp = client.get("/api/messages/999999")
    assert resp.status_code == 404


def test_verify_message_valid(client):
    created = client.post("/api/messages", json={"message_type": "BootNotification", "migration_mode": "HYBRID"}).json()
    resp = client.post("/api/messages/verify", json={"message_id": created["id"], "allow_legacy_fallback": False})
    assert resp.status_code == 200
    body = resp.json()
    assert body["valid"] is True
    assert body["method_used"] == "SHA3-256"


def test_tamper_then_verify_detects_invalid(client):
    created = client.post("/api/messages", json={"message_type": "StopTransaction", "migration_mode": "HYBRID"}).json()
    tampered = client.post("/api/messages/tamper", json={"message_id": created["id"]}).json()
    assert tampered["verification_status"] == "INVALID"
    assert tampered["is_tampered"] is True


def test_hash_compare_endpoint(client):
    resp = client.post("/api/hash/compare", json={"text": "hello world", "rounds": 5})
    assert resp.status_code == 200
    rows = resp.json()["rows"]
    assert len(rows) == 4


def test_hash_compare_requires_text_or_message_id(client):
    resp = client.post("/api/hash/compare", json={"rounds": 5})
    assert resp.status_code == 400


def test_collision_demo_endpoint(client):
    resp = client.get("/api/collision-demo?truncate_bits=12")
    assert resp.status_code == 200
    body = resp.json()
    assert body["message_a"] != body["message_b"]
    assert body["truncated_md5_equal"] is True


def test_migration_modes_endpoint(client):
    resp = client.get("/api/migration/modes")
    assert resp.status_code == 200
    body = resp.json()
    assert set(body["modes"]) == {"LEGACY", "HYBRID", "MODERN"}


def test_set_default_mode(client):
    resp = client.post("/api/migration/mode?mode=MODERN")
    assert resp.status_code == 200
    assert resp.json()["current_default_mode"] == "MODERN"


def test_set_invalid_mode_returns_400(client):
    resp = client.post("/api/migration/mode?mode=NOT_REAL")
    assert resp.status_code == 400


def test_system_status_endpoint(client):
    client.post("/api/messages", json={"migration_mode": "HYBRID"})
    resp = client.get("/api/system/status")
    assert resp.status_code == 200
    body = resp.json()
    assert body["total_messages"] >= 1


def test_migration_verify_endpoint_standalone(client):
    created = client.post("/api/messages", json={"migration_mode": "MODERN"}).json()
    resp = client.post(
        "/api/migration/verify",
        json={"wrapped_message": created["wrapped"], "allow_legacy_fallback": False},
    )
    assert resp.status_code == 200
    assert resp.json()["valid"] is True


def test_malformed_message_body_rejected(client):
    resp = client.post("/api/messages", json={"migration_mode": "NOT_A_MODE"})
    assert resp.status_code == 400
