"""Tests for the EV/OCPP simulator, the collision fixture demo, and the comparison module."""

import hashlib

import pytest

from app.crypto import collision_fixture, comparison
from app.simulator import ev_charger


@pytest.mark.parametrize("msg_type", list(ev_charger.OcppMessageType))
def test_generate_message_has_required_fields(msg_type):
    msg = ev_charger.generate_message(msg_type, "CP-9999")
    assert msg["message_type"] == msg_type.value
    assert msg["charger_id"] == "CP-9999"
    assert "payload" in msg
    assert "timestamp" in msg
    assert "message_id" in msg


def test_generate_random_message_picks_a_valid_type():
    msg = ev_charger.generate_random_message()
    assert msg["message_type"] in [m.value for m in ev_charger.OcppMessageType]


def test_tamper_message_does_not_mutate_original():
    original = ev_charger.generate_message(ev_charger.OcppMessageType.START_TRANSACTION, "CP-1")
    original_copy = dict(original)
    tampered = ev_charger.tamper_message(original)
    assert original == original_copy  # original untouched
    assert tampered != original       # tampered copy differs


def test_tamper_message_changes_payload():
    original = ev_charger.generate_message(ev_charger.OcppMessageType.METER_VALUES, "CP-2")
    tampered = ev_charger.tamper_message(original)
    assert tampered["payload"] != original["payload"]


# ---------------- Collision fixture ----------------

def test_collision_demo_produces_different_messages_with_equal_truncated_md5():
    result = collision_fixture.find_truncated_md5_collision(truncate_bits=16)
    assert result.message_a != result.message_b
    assert result.truncated_md5_equal is True

    # Independently re-verify: this is not hardcoded, it's a real recomputation.
    def trunc(msg, bits):
        d = hashlib.md5(msg.encode()).digest()  # noqa: S324
        return int.from_bytes(d, "big") >> (128 - bits)

    assert trunc(result.message_a, 16) == trunc(result.message_b, 16)


def test_collision_demo_full_md5_may_differ_and_sha3_differs():
    result = collision_fixture.find_truncated_md5_collision(truncate_bits=16)
    # SHA3-256 must not share the truncated-MD5 collision (different construction).
    assert result.sha3_256_a != result.sha3_256_b
    assert result.sha3_256_equal is False


def test_collision_demo_invalid_bits_raises():
    with pytest.raises(ValueError):
        collision_fixture.find_truncated_md5_collision(truncate_bits=2)
    with pytest.raises(ValueError):
        collision_fixture.find_truncated_md5_collision(truncate_bits=64)


# ---------------- Comparison ----------------

def test_compare_all_returns_four_algorithms():
    rows = comparison.compare_all("sample message", rounds=5)
    algos = {r["algorithm"] for r in rows}
    assert algos == {"MD5", "SHA-1", "SHA-256", "SHA3-256"}


def test_compare_all_accepts_dict_message():
    rows = comparison.compare_all({"a": 1, "b": 2}, rounds=5)
    assert len(rows) == 4
    for r in rows:
        assert r["digest_hex"]
        assert r["avg_time_microseconds"] >= 0
