"""Tests for MD5, SHA-1, SHA-256, SHA3-256 digest generation."""

import hashlib

from app.crypto import md5_legacy, sha1, sha256, sha3


def test_md5_digest_matches_hashlib():
    data = b"hello ev charger"
    result = md5_legacy.md5_digest(data)
    assert result.digest_hex == hashlib.md5(data).hexdigest()
    assert result.digest_length_bytes == 16
    assert result.hex_length_chars == 32


def test_sha1_digest_matches_hashlib():
    data = b"hello ev charger"
    result = sha1.sha1_digest(data)
    assert result.digest_hex == hashlib.sha1(data).hexdigest()
    assert result.digest_length_bytes == 20


def test_sha256_digest_matches_hashlib():
    data = b"hello ev charger"
    result = sha256.sha256_digest(data)
    assert result.digest_hex == hashlib.sha256(data).hexdigest()
    assert result.digest_length_bytes == 32


def test_sha3_256_digest_matches_hashlib():
    data = b"hello ev charger"
    result = sha3.sha3_256_digest(data)
    assert result.digest_hex == hashlib.sha3_256(data).hexdigest()
    assert result.digest_length_bytes == 32


def test_different_inputs_produce_different_digests_all_algorithms():
    a, b = b"message A", b"message B"
    assert md5_legacy.md5_digest(a).digest_hex != md5_legacy.md5_digest(b).digest_hex
    assert sha1.sha1_digest(a).digest_hex != sha1.sha1_digest(b).digest_hex
    assert sha256.sha256_digest(a).digest_hex != sha256.sha256_digest(b).digest_hex
    assert sha3.sha3_256_digest(a).digest_hex != sha3.sha3_256_digest(b).digest_hex


def test_hmac_sha3_256_valid_and_invalid():
    key = b"secret-key"
    data = b"authenticated payload"
    tag = sha3.hmac_sha3_256(data, key)
    assert sha3.verify_hmac_sha3_256(data, key, tag.tag_hex) is True
    assert sha3.verify_hmac_sha3_256(b"tampered payload", key, tag.tag_hex) is False
    assert sha3.verify_hmac_sha3_256(data, b"wrong-key", tag.tag_hex) is False


def test_canonical_serialize_is_deterministic():
    m1 = {"b": 2, "a": 1}
    m2 = {"a": 1, "b": 2}
    assert md5_legacy.canonical_serialize(m1) == md5_legacy.canonical_serialize(m2)


def test_verify_md5_true_for_correct_digest_false_for_wrong():
    message = {"foo": "bar", "n": 1}
    digest = md5_legacy.md5_of_message(message)
    assert md5_legacy.verify_md5(message, digest) is True
    assert md5_legacy.verify_md5(message, "0" * 32) is False


def test_invalid_digest_handling_does_not_raise():
    message = {"foo": "bar"}
    # malformed / short digest should just fail verification, not crash
    assert md5_legacy.verify_md5(message, "not-a-real-digest") is False
