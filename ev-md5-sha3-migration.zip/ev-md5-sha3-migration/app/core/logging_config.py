"""
logging_config.py
==================

Centralized logging setup. Logs are written locally to data/ev_lab.log
and echoed to stdout -- never transmitted anywhere. Security-relevant
events (integrity failures, collision-demo runs, migration mode
changes) are logged at WARNING/INFO level so they show up clearly in
the "Security Analysis / logs" part of the demo.
"""

from __future__ import annotations

import logging
import sys
from pathlib import Path

from app.core.db import DATA_DIR

LOG_PATH = DATA_DIR / "ev_lab.log"


def configure_logging(level: int = logging.INFO) -> logging.Logger:
    logger = logging.getLogger("ev_lab")
    if logger.handlers:
        return logger  # already configured

    logger.setLevel(level)
    fmt = logging.Formatter(
        "%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
        datefmt="%Y-%m-%dT%H:%M:%S%z",
    )

    stream_handler = logging.StreamHandler(sys.stdout)
    stream_handler.setFormatter(fmt)
    logger.addHandler(stream_handler)

    file_handler = logging.FileHandler(LOG_PATH, encoding="utf-8")
    file_handler.setFormatter(fmt)
    logger.addHandler(file_handler)

    return logger


logger = configure_logging()
