"""
messages.py
===========

API endpoints for generating, listing, verifying, and tampering with
simulated EV messages.
"""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.core.db import get_db
from app.models.schemas import (
    GenerateMessageRequest,
    MessageResponse,
    TamperMessageRequest,
    VerifyMessageRequest,
    VerifyMessageResponse,
)
from app.services import message_service

router = APIRouter(prefix="/messages", tags=["messages"])


@router.post("", response_model=MessageResponse)
def create_message(req: GenerateMessageRequest, db: Session = Depends(get_db)):
    try:
        record = message_service.create_message(
            db, req.message_type, req.charger_id, req.migration_mode
        )
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    return message_service.to_response_dict(record)


@router.get("", response_model=list[MessageResponse])
def list_messages(limit: int = 100, db: Session = Depends(get_db)):
    records = message_service.list_messages(db, limit=limit)
    return [message_service.to_response_dict(r) for r in records]


@router.get("/{message_id}", response_model=MessageResponse)
def get_message(message_id: int, db: Session = Depends(get_db)):
    record = message_service.get_message(db, message_id)
    if record is None:
        raise HTTPException(status_code=404, detail="Message not found")
    return message_service.to_response_dict(record)


@router.post("/verify", response_model=VerifyMessageResponse)
def verify_message(req: VerifyMessageRequest, db: Session = Depends(get_db)):
    try:
        record, result = message_service.verify_message(
            db, req.message_id, allow_legacy_fallback=req.allow_legacy_fallback
        )
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    return VerifyMessageResponse(
        message_id=record.id,
        valid=result.valid,
        method_used=result.method_used.value,
        migration_mode=result.migration_mode.value,
        downgraded=result.downgraded,
        details=result.details,
    )


@router.post("/tamper", response_model=MessageResponse)
def tamper_message(req: TamperMessageRequest, db: Session = Depends(get_db)):
    try:
        record, _ = message_service.tamper_message(db, req.message_id)
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
    return message_service.to_response_dict(record)
