"""
analysis.py
===========

API endpoints for hash comparison, the collision demo, migration
verification, and system status.
"""

from __future__ import annotations

import json

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.core.db import get_db
from app.crypto import migration
from app.crypto.comparison import compare_all
from app.models.schemas import (
    CollisionDemoRequest,
    HashCompareRequest,
    MigrationVerifyRequest,
    SystemStatusResponse,
)
from app.services import collision_service, message_service, status_service

router = APIRouter(tags=["analysis"])

# Tracks the server's "current default mode" shown on the dashboard --
# purely a UI convenience; each message still carries its own mode.
_CURRENT_DEFAULT_MODE = {"value": migration.MigrationMode.HYBRID.value}


@router.post("/hash/compare")
def hash_compare(req: HashCompareRequest, db: Session = Depends(get_db)):
    if req.message_id is not None:
        record = message_service.get_message(db, req.message_id)
        if record is None:
            raise HTTPException(status_code=404, detail="Message not found")
        wrapped = json.loads(record.payload_json)
        target = wrapped.get("legacy_message", {})
    elif req.text is not None:
        target = req.text
    else:
        raise HTTPException(status_code=400, detail="Provide either 'text' or 'message_id'.")

    return {"input_summary": str(target)[:200], "rows": compare_all(target, rounds=req.rounds)}


@router.get("/collision-demo")
def collision_demo(truncate_bits: int = 24, db: Session = Depends(get_db)):
    try:
        result = collision_service.run_collision_demo(db, truncate_bits=truncate_bits)
    except (ValueError, RuntimeError) as e:
        raise HTTPException(status_code=400, detail=str(e))
    return result.__dict__


@router.post("/migration/verify")
def migration_verify(req: MigrationVerifyRequest):
    result = migration.verify_wrapped_message(
        req.wrapped_message, allow_legacy_fallback=req.allow_legacy_fallback
    )
    return {
        "valid": result.valid,
        "method_used": result.method_used.value,
        "migration_mode": result.migration_mode.value,
        "downgraded": result.downgraded,
        "details": result.details,
    }


@router.get("/migration/modes")
def migration_modes():
    return {
        "modes": [m.value for m in migration.MigrationMode],
        "summary": migration.migration_mode_security_summary(),
        "current_default_mode": _CURRENT_DEFAULT_MODE["value"],
    }


@router.post("/migration/mode")
def set_default_mode(mode: str, db: Session = Depends(get_db)):
    try:
        parsed = migration.MigrationMode(mode)
    except ValueError:
        raise HTTPException(status_code=400, detail=f"Invalid mode: {mode}")

    from app.models.db_models import MigrationEvent

    event = MigrationEvent(
        old_algorithm=_CURRENT_DEFAULT_MODE["value"],
        new_algorithm=parsed.value,
        status="APPLIED",
        details=f"Default migration mode changed to {parsed.value}.",
    )
    db.add(event)
    db.commit()

    _CURRENT_DEFAULT_MODE["value"] = parsed.value
    return {"current_default_mode": _CURRENT_DEFAULT_MODE["value"]}


@router.get("/system/status", response_model=SystemStatusResponse)
def system_status(db: Session = Depends(get_db)):
    return status_service.get_system_status(db, _CURRENT_DEFAULT_MODE["value"])


def get_current_default_mode() -> str:
    return _CURRENT_DEFAULT_MODE["value"]
