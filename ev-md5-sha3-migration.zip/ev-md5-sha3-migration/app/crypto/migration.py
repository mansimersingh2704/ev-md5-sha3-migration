"""
migration.py
============

THE MAIN CONTRIBUTION OF THIS PROJECT.

A backward-compatible integrity-migration wrapper for legacy EV/CSMS
message formats. The design goal: a legacy parser can keep consuming
`wrapped["legacy_message"]` completely unchanged, while upgraded
clients get modern SHA-3 (or HMAC-SHA3) verification for free.

Wrapper shape (version 2)
--------------------------
{
    "version": 2,
    "legacy_message": {...},        # untouched, legacy-parseable
    "legacy_md5": "...",            # for legacy-compat verification only
    "sha3_256": "...",              # modern integrity digest
    "hmac_sha3_256": "..." | null,  # present only in MODERN mode
    "algorithm": "SHA3-256" | "HMAC-SHA3-256",
    "migration_mode": "LEGACY" | "HYBRID" | "MODERN"
}

Migration modes
-----------------
LEGACY  - Only MD5 is computed/verified. Behaves exactly like the
          unmodified legacy system. Included so the project can show
          the "before" state, and so a fleet can be migrated
          incrementally charger-by-charger rather than all at once.

HYBRID  - Both MD5 (for legacy-compatibility / transition period) and
          SHA3-256 (for upgraded clients) are computed and attached.
          Verification PREFERS SHA3-256 and only falls back to MD5
          when explicitly configured to (`allow_legacy_fallback=True`),
          because otherwise HYBRID mode would silently downgrade
          security to LEGACY mode's level, which defeats the purpose
          of migrating at all. This mirrors real-world protocol
          downgrade-attack concerns (see docs/THREAT_MODEL.md).

MODERN  - MD5 is not computed at all. Integrity/authenticity is
          verified with HMAC-SHA3-256 using a shared secret. This is
          the only mode that provides AUTHENTICITY, not just
          corruption-detection, because it is a keyed MAC rather than
          a bare hash (see app/crypto/sha3.py docstring).

Explicit non-goal
-------------------
This wrapper does not implement replay protection, sequence numbers,
or transport encryption. Those are separate controls, listed in
docs/THREAT_MODEL.md, and out of scope for a hashing/migration demo.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Optional

from app.crypto import md5_legacy, sha3

WRAPPER_VERSION = 2

# Fixed demo HMAC key. In a real deployment this MUST be a securely
# provisioned, per-charger secret (e.g. injected at manufacture time
# or via a secure onboarding flow) -- never hardcoded. It is hardcoded
# here only because this is a local, offline teaching lab.
DEMO_HMAC_KEY = b"lab-demo-shared-secret-DO-NOT-USE-IN-PRODUCTION"


class MigrationMode(str, Enum):
    LEGACY = "LEGACY"
    HYBRID = "HYBRID"
    MODERN = "MODERN"


class VerificationMethod(str, Enum):
    MD5 = "MD5"
    SHA3_256 = "SHA3-256"
    HMAC_SHA3_256 = "HMAC-SHA3-256"
    NONE = "NONE"


@dataclass
class WrappedMessage:
    version: int
    legacy_message: dict[str, Any]
    migration_mode: MigrationMode
    legacy_md5: Optional[str] = None
    sha3_256: Optional[str] = None
    hmac_sha3_256: Optional[str] = None
    algorithm: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "version": self.version,
            "legacy_message": self.legacy_message,
            "legacy_md5": self.legacy_md5,
            "sha3_256": self.sha3_256,
            "hmac_sha3_256": self.hmac_sha3_256,
            "algorithm": self.algorithm,
            "migration_mode": self.migration_mode.value,
        }


@dataclass
class VerificationResult:
    valid: bool
    method_used: VerificationMethod
    migration_mode: MigrationMode
    details: str
    downgraded: bool = False  # True if we had to fall back to a weaker method


def wrap_message(
    legacy_message: dict[str, Any],
    mode: MigrationMode,
    hmac_key: bytes = DEMO_HMAC_KEY,
) -> WrappedMessage:
    """
    Wrap a legacy EV message with integrity metadata appropriate to
    the given migration mode, WITHOUT modifying legacy_message itself.
    """
    canonical = md5_legacy.canonical_serialize(legacy_message)

    if mode is MigrationMode.LEGACY:
        digest = md5_legacy.md5_digest(canonical)
        return WrappedMessage(
            version=WRAPPER_VERSION,
            legacy_message=legacy_message,
            migration_mode=mode,
            legacy_md5=digest.digest_hex,
            algorithm=VerificationMethod.MD5.value,
        )

    if mode is MigrationMode.HYBRID:
        md5_result = md5_legacy.md5_digest(canonical)
        sha3_result = sha3.sha3_256_digest(canonical)
        return WrappedMessage(
            version=WRAPPER_VERSION,
            legacy_message=legacy_message,
            migration_mode=mode,
            legacy_md5=md5_result.digest_hex,
            sha3_256=sha3_result.digest_hex,
            algorithm=VerificationMethod.SHA3_256.value,
        )

    # MODERN
    tag = sha3.hmac_sha3_256(canonical, hmac_key)
    return WrappedMessage(
        version=WRAPPER_VERSION,
        legacy_message=legacy_message,
        migration_mode=mode,
        hmac_sha3_256=tag.tag_hex,
        algorithm=VerificationMethod.HMAC_SHA3_256.value,
    )


def verify_wrapped_message(
    wrapped: dict[str, Any],
    allow_legacy_fallback: bool = False,
    hmac_key: bytes = DEMO_HMAC_KEY,
) -> VerificationResult:
    """
    Verify a wrapped message according to its declared migration_mode.

    Rules (deliberately explicit, no silent downgrades):
      * LEGACY  -> MD5 only. Always the weakest guarantee.
      * HYBRID  -> SHA3-256 is checked first and preferred. MD5 is only
                   used as a fallback if SHA3-256 data is missing AND
                   the caller has explicitly opted in via
                   `allow_legacy_fallback=True`. Otherwise verification
                   fails closed rather than silently trusting MD5.
      * MODERN  -> HMAC-SHA3-256 only. No MD5 fallback exists in this
                   mode at all -- MD5 is never computed for MODERN
                   messages in the first place.
    """
    legacy_message = wrapped.get("legacy_message")
    if not isinstance(legacy_message, dict):
        return VerificationResult(
            valid=False,
            method_used=VerificationMethod.NONE,
            migration_mode=MigrationMode(wrapped.get("migration_mode", "LEGACY")),
            details="Malformed wrapper: 'legacy_message' missing or not an object.",
        )

    try:
        mode = MigrationMode(wrapped.get("migration_mode", "LEGACY"))
    except ValueError:
        return VerificationResult(
            valid=False,
            method_used=VerificationMethod.NONE,
            migration_mode=MigrationMode.LEGACY,
            details=f"Unknown migration_mode: {wrapped.get('migration_mode')!r}",
        )

    canonical = md5_legacy.canonical_serialize(legacy_message)

    if mode is MigrationMode.LEGACY:
        expected = wrapped.get("legacy_md5")
        if not expected:
            return VerificationResult(False, VerificationMethod.MD5, mode, "Missing legacy_md5 field.")
        ok = md5_legacy.verify_md5(legacy_message, expected)
        return VerificationResult(
            valid=ok,
            method_used=VerificationMethod.MD5,
            migration_mode=mode,
            details="Verified against legacy MD5 only. "
                    "NOTE: MD5 cannot detect a deliberately crafted collision.",
        )

    if mode is MigrationMode.HYBRID:
        sha3_expected = wrapped.get("sha3_256")
        if sha3_expected:
            actual = sha3.sha3_256_digest(canonical).digest_hex
            ok = actual == sha3_expected
            return VerificationResult(
                valid=ok,
                method_used=VerificationMethod.SHA3_256,
                migration_mode=mode,
                details="Verified using SHA3-256 (preferred path for HYBRID mode).",
            )
        # No SHA3-256 present -- only fall back if explicitly allowed.
        if allow_legacy_fallback and wrapped.get("legacy_md5"):
            ok = md5_legacy.verify_md5(legacy_message, wrapped["legacy_md5"])
            return VerificationResult(
                valid=ok,
                method_used=VerificationMethod.MD5,
                migration_mode=mode,
                details="SHA3-256 unavailable; explicitly allowed fallback to MD5. "
                        "This is a reduced-security path -- should only be used "
                        "temporarily during a fleet migration window.",
                downgraded=True,
            )
        return VerificationResult(
            valid=False,
            method_used=VerificationMethod.NONE,
            migration_mode=mode,
            details="SHA3-256 missing and legacy fallback not explicitly allowed. "
                    "Failing closed to avoid a silent downgrade to MD5.",
        )

    # MODERN
    expected_tag = wrapped.get("hmac_sha3_256")
    if not expected_tag:
        return VerificationResult(
            False, VerificationMethod.HMAC_SHA3_256, mode, "Missing hmac_sha3_256 field."
        )
    ok = sha3.verify_hmac_sha3_256(canonical, hmac_key, expected_tag)
    return VerificationResult(
        valid=ok,
        method_used=VerificationMethod.HMAC_SHA3_256,
        migration_mode=mode,
        details="Verified using HMAC-SHA3-256 (authenticated integrity; "
                "requires possession of the shared secret).",
    )


def migration_mode_security_summary() -> list[dict[str, str]]:
    """Static, human-readable summary used by the dashboard's mode explainer."""
    return [
        {
            "mode": MigrationMode.LEGACY.value,
            "guarantee": "Corruption detection only (non-adversarial).",
            "risk": "Vulnerable to deliberate collision-based substitution. No authenticity.",
        },
        {
            "mode": MigrationMode.HYBRID.value,
            "guarantee": "Strong integrity via SHA3-256 for upgraded clients; MD5 kept only for a bounded transition window.",
            "risk": "If fallback is misconfigured to always allow MD5, effective security regresses to LEGACY.",
        },
        {
            "mode": MigrationMode.MODERN.value,
            "guarantee": "Authenticated integrity via HMAC-SHA3-256 (requires shared secret).",
            "risk": "Requires secure key provisioning/rotation; no MD5 compatibility at all.",
        },
    ]
