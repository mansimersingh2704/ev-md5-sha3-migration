"""
md5_legacy.py
=============

SECURITY WARNING
-----------------
MD5 is CRYPTOGRAPHICALLY BROKEN. It is:
  * Not collision-resistant (Wang et al., 2004 - practical collisions).
  * Not suitable for digital signatures, certificate signing, or any
    integrity/authenticity decision that an adversary could influence.
  * Still fast/cheap, which is exactly why legacy embedded systems
    (like older EV charge-point firmware) kept using it for simple
    "did this get corrupted in transit" checksums.

This module exists ONLY to:
  1. Faithfully reproduce how a legacy EV CSMS/firmware integration
     might have used MD5 for message integrity, so the risk can be
     demonstrated and measured.
  2. Provide a single, isolated place in the codebase where MD5 is
     used. No other module in this project should import hashlib.md5
     directly -- everything routes through here so the "blast radius"
     of the broken primitive is contained and auditable.

DO NOT use this module as a template for new designs. See
app/crypto/sha3.py and app/crypto/migration.py for the recommended
replacement.
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from typing import Any


LEGACY_ALGORITHM_NAME = "MD5"
IS_BROKEN = True
SECURITY_NOTE = (
    "MD5 provides NO collision resistance guarantees. Two different "
    "inputs can be deliberately crafted to produce the same MD5 digest "
    "(see app/services/collision_service.py for a live demonstration). "
    "MD5 must never be relied upon to prove that a message was not "
    "tampered with by a capable adversary; it only detects accidental "
    "bit-level corruption in a non-adversarial setting."
)


def canonical_serialize(message: dict[str, Any]) -> bytes:
    """
    Serialize a message dict the way a legacy embedded parser would:
    deterministic key ordering, compact separators, UTF-8 bytes.

    Using a canonical form matters -- if serialization were not
    deterministic, two "identical" messages could hash differently,
    which would itself be a (different) integrity bug. This is a
    correctness concern, not a security fix for MD5's weaknesses.
    """
    return json.dumps(message, sort_keys=True, separators=(",", ":")).encode("utf-8")


@dataclass(frozen=True)
class Md5Result:
    algorithm: str
    digest_hex: str
    digest_length_bytes: int
    hex_length_chars: int


def md5_digest(data: bytes) -> Md5Result:
    """Compute the MD5 digest of raw bytes. Isolated on purpose -- see module docstring."""
    h = hashlib.md5(data)  # noqa: S324 - intentional, isolated legacy usage
    digest = h.digest()
    return Md5Result(
        algorithm=LEGACY_ALGORITHM_NAME,
        digest_hex=h.hexdigest(),
        digest_length_bytes=len(digest),
        hex_length_chars=len(h.hexdigest()),
    )


def md5_of_message(message: dict[str, Any]) -> str:
    """Convenience: canonical-serialize an EV message and return its MD5 hex digest."""
    return md5_digest(canonical_serialize(message)).digest_hex


def verify_md5(message: dict[str, Any], expected_digest_hex: str) -> bool:
    """
    Legacy-style integrity check: recompute MD5 and compare.

    IMPORTANT: A `True` result here means "the bytes match what produced
    this MD5 value" in a non-adversarial setting. It does NOT mean the
    message is authentic or that an attacker did not tamper with it --
    see app/services/collision_service.py and docs/THREAT_MODEL.md.
    """
    actual = md5_of_message(message)
    return _constant_time_eq(actual, expected_digest_hex)


def _constant_time_eq(a: str, b: str) -> bool:
    """Constant-time string comparison to avoid trivial timing side channels."""
    import hmac as _hmac

    return _hmac.compare_digest(a.encode(), b.encode())
