"""
collision_fixture.py
=====================

SAFE, LOCAL, EDUCATIONAL MD5 collision demonstration.

WHY NOT SHIP "THE FAMOUS" COLLISION BYTES VERBATIM
-----------------------------------------------------
Several real, publicly documented MD5 collision pairs exist in the
academic literature (Wang, Feng, Lai & Yu, 2004; later chosen-prefix
work by Stevens et al.). This project intentionally does NOT hardcode
transcribed "famous" collision bytes from memory, because:

  1. A single transcription error silently produces two inputs that
     DO NOT actually collide -- which would make the "flagship" demo
     of a security project quietly wrong, which is worse than not
     having it.
  2. A hash collision claim should be independently, locally
     verifiable by re-hashing the bytes -- not taken on faith from a
     hardcoded string.

WHAT THIS MODULE DOES INSTEAD
--------------------------------
It runs a REAL, LOCAL, VERIFIABLE birthday-attack-style search for two
different messages that collide -- but against a deliberately
TRUNCATED MD5 output (default: the top `truncate_bits` bits of the
128-bit digest, default 24 bits). This is a standard, honest teaching
simplification:

  * A full 128-bit MD5 collision requires on the order of 2^64
    operations even using the birthday-attack shortcut -- infeasible
    to compute live in a college lab / CI environment.
  * Truncating to `truncate_bits` bits shrinks the birthday-bound
    search space to roughly 2^(bits/2) attempts, which completes in
    milliseconds for bits<=32, while using the exact same underlying
    MD5 compression function and the exact same birthday-attack logic
    that real MD5 cryptanalysis exploits.
  * The two messages ARE genuinely different byte strings, and their
    (truncated) MD5 digests ARE genuinely, verifiably equal -- nothing
    is faked or hardcoded.

This module also independently computes each message's SHA3-256
digest to show that the same "collision" does NOT carry over to
SHA3-256 (as expected -- SHA3-256's output space is astronomically
larger and the truncation trick that "worked" against MD5-24 has no
special relationship to Keccak).

For anyone extending this project towards a full, untruncated,
128-bit real-world MD5 collision, `docs/README.md` documents where to
source genuinely published collision file pairs (e.g. via published
academic chosen-prefix collision tooling) rather than guessing at
transcribed bytes.
"""

from __future__ import annotations

import hashlib
import time
from dataclasses import dataclass
from typing import Optional

from app.crypto import sha3


def _truncated_md5_int(data: bytes, bits: int) -> int:
    digest = hashlib.md5(data).digest()  # noqa: S324 - intentional, isolated demo usage
    full = int.from_bytes(digest, "big")
    return full >> (128 - bits)


def _truncated_md5_hex(data: bytes, bits: int) -> str:
    value = _truncated_md5_int(data, bits)
    nibbles = (bits + 3) // 4
    return format(value, f"0{nibbles}x")


@dataclass
class CollisionResult:
    message_a: str
    message_b: str
    truncate_bits: int
    truncated_md5_a: str
    truncated_md5_b: str
    truncated_md5_equal: bool
    full_md5_a: str
    full_md5_b: str
    full_md5_equal: bool
    sha3_256_a: str
    sha3_256_b: str
    sha3_256_equal: bool
    iterations: int
    search_time_seconds: float
    explanation: str


def find_truncated_md5_collision(
    truncate_bits: int = 24,
    prefix: str = "EV-CSMS-lab-msg-",
    max_iterations: int = 5_000_000,
) -> CollisionResult:
    """
    Brute-force search for two distinct short strings whose MD5 digests
    agree on the top `truncate_bits` bits. Returns full details
    including the REAL (untruncated) MD5 and SHA3-256 digests of both
    messages, so the dashboard can show that the collision does NOT
    hold for the full 128-bit MD5 output or for SHA3-256.
    """
    if not (4 <= truncate_bits <= 40):
        raise ValueError("truncate_bits must be between 4 and 40 for a fast local demo.")

    start = time.perf_counter()
    seen: dict[int, str] = {}
    msg_a: Optional[str] = None
    msg_b: Optional[str] = None
    i = 0
    while i < max_iterations:
        candidate = f"{prefix}{i}"
        h = _truncated_md5_int(candidate.encode("utf-8"), truncate_bits)
        if h in seen:
            msg_a = seen[h]
            msg_b = candidate
            break
        seen[h] = candidate
        i += 1
    elapsed = time.perf_counter() - start

    if msg_a is None or msg_b is None:
        raise RuntimeError(
            f"No collision found within {max_iterations} iterations for "
            f"truncate_bits={truncate_bits}. Try a smaller truncate_bits value."
        )

    full_md5_a = hashlib.md5(msg_a.encode()).hexdigest()  # noqa: S324
    full_md5_b = hashlib.md5(msg_b.encode()).hexdigest()  # noqa: S324
    sha3_a = sha3.sha3_256_digest(msg_a.encode()).digest_hex
    sha3_b = sha3.sha3_256_digest(msg_b.encode()).digest_hex

    return CollisionResult(
        message_a=msg_a,
        message_b=msg_b,
        truncate_bits=truncate_bits,
        truncated_md5_a=_truncated_md5_hex(msg_a.encode(), truncate_bits),
        truncated_md5_b=_truncated_md5_hex(msg_b.encode(), truncate_bits),
        truncated_md5_equal=True,
        full_md5_a=full_md5_a,
        full_md5_b=full_md5_b,
        full_md5_equal=(full_md5_a == full_md5_b),
        sha3_256_a=sha3_a,
        sha3_256_b=sha3_b,
        sha3_256_equal=(sha3_a == sha3_b),
        iterations=i + 1,
        search_time_seconds=elapsed,
        explanation=(
            f"Two DIFFERENT messages were found whose MD5 digests agree on the "
            f"top {truncate_bits} bits (a real, locally-verifiable birthday-attack "
            f"collision against a truncated MD5 output space, found in {i+1} "
            f"attempts / {elapsed:.4f}s). This models, at demonstrable scale, why "
            f"MD5 must not be trusted for collision resistance: given enough "
            f"attempts, an adversary CAN construct two different messages that a "
            f"legacy MD5 integrity check would treat as consistent. Their full "
            f"128-bit MD5 digests are shown for reference (they will typically "
            f"differ, since only the top bits were targeted). Their SHA3-256 "
            f"digests are shown to confirm SHA3-256 does not share this weakness."
        ),
    )
