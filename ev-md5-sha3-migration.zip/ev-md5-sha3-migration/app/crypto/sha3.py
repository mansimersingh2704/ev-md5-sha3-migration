"""
sha3.py
=======

SHA-3 (Keccak) is the target algorithm for this project's migration.

Why SHA-3 and not "just a bigger SHA-2"?
-----------------------------------------
SHA-3 uses a *sponge construction* built on the Keccak permutation,
which is structurally independent from the Merkle-Damgard construction
used by MD5, SHA-1, and SHA-256. This matters because:

  * MD5 and SHA-1 were broken via attacks that exploit properties of
    the Merkle-Damgard construction combined with weak internal
    compression functions.
  * SHA-256 (also Merkle-Damgard) is currently unbroken, but NIST
    standardized SHA-3 specifically so that the ecosystem is not
    "putting all its eggs in one basket" -- if a future structural
    weakness were ever found in Merkle-Damgard-family designs, SHA-3
    would not automatically inherit it.
  * SHA-3 also offers built-in resistance to length-extension attacks,
    which SHA-256 (used naively) does not.

IMPORTANT LIMITATION THIS PROJECT IS EXPLICIT ABOUT
-----------------------------------------------------
A bare hash -- MD5, SHA-256, or SHA3-256 -- is an INTEGRITY primitive,
not an AUTHENTICITY primitive. If an attacker can modify the message
in transit, they can also recompute a new plain hash over the modified
message and attach that instead, unless the hash is bound to a secret
the attacker does not have. That is exactly what HMAC (Hash-based
Message Authentication Code) is for. This module therefore also
provides `hmac_sha3_256`, and app/crypto/migration.py's MODERN mode
uses HMAC-SHA3, not a bare SHA3-256 digest, when authenticity (not
just corruption-detection) is required.
"""

from __future__ import annotations

import hashlib
import hmac
from dataclasses import dataclass

ALGORITHM_NAME = "SHA3-256"
IS_DEPRECATED = False
SECURITY_NOTE = (
    "SHA3-256 (Keccak sponge construction) has no known practical "
    "collision or preimage attacks and is structurally independent "
    "from the SHA-2/SHA-1/MD5 Merkle-Damgard family. Recommended for "
    "new integrity designs. For AUTHENTICITY (protection against an "
    "adversary who can also modify the accompanying hash), use "
    "HMAC-SHA3-256 with a secret key, not a bare digest."
)


@dataclass(frozen=True)
class Sha3Result:
    algorithm: str
    digest_hex: str
    digest_length_bytes: int
    hex_length_chars: int


def sha3_256_digest(data: bytes) -> Sha3Result:
    h = hashlib.sha3_256(data)
    digest = h.digest()
    return Sha3Result(
        algorithm=ALGORITHM_NAME,
        digest_hex=h.hexdigest(),
        digest_length_bytes=len(digest),
        hex_length_chars=len(h.hexdigest()),
    )


@dataclass(frozen=True)
class HmacSha3Result:
    algorithm: str
    tag_hex: str
    tag_length_bytes: int


def hmac_sha3_256(data: bytes, key: bytes) -> HmacSha3Result:
    """
    Compute an HMAC-SHA3-256 authentication tag.

    Unlike a bare digest, this binds the tag to a shared secret `key`.
    An attacker who intercepts and modifies `data` cannot produce a
    valid tag for the modified data without knowing `key`. This is the
    primitive that should back any "authenticity", not just
    "integrity", claim in a production migration.
    """
    mac = hmac.new(key, data, hashlib.sha3_256)
    return HmacSha3Result(
        algorithm="HMAC-SHA3-256",
        tag_hex=mac.hexdigest(),
        tag_length_bytes=mac.digest_size,
    )


def verify_hmac_sha3_256(data: bytes, key: bytes, expected_tag_hex: str) -> bool:
    computed = hmac_sha3_256(data, key).tag_hex
    return hmac.compare_digest(computed, expected_tag_hex)
