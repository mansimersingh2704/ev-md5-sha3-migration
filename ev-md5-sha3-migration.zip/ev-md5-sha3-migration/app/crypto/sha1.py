"""
sha1.py
=======

SHA-1 is DEPRECATED for security purposes. NIST formally disallowed
SHA-1 for digital signatures as of 2013, and practical chosen-prefix
collisions were demonstrated publicly in 2017 (Google/CWI "SHAttered")
and improved further in 2020 ("SHA-1 is a Shambles"). It is included
here only for comparison purposes in the hash-comparison module, so
the project can show a full historical progression:

    MD5 (broken)  ->  SHA-1 (deprecated)  ->  SHA-256 (widely used)  ->  SHA-3 (modern)
"""

from __future__ import annotations

import hashlib
from dataclasses import dataclass

ALGORITHM_NAME = "SHA-1"
IS_DEPRECATED = True
SECURITY_NOTE = (
    "SHA-1 has practical, demonstrated collision attacks (chosen-prefix "
    "collisions since 2017/2020). It must not be used for certificates, "
    "signatures, or any new integrity design. Included here for "
    "historical/comparative purposes only."
)


@dataclass(frozen=True)
class Sha1Result:
    algorithm: str
    digest_hex: str
    digest_length_bytes: int
    hex_length_chars: int


def sha1_digest(data: bytes) -> Sha1Result:
    h = hashlib.sha1(data)  # noqa: S324 - intentional, comparison-only usage
    digest = h.digest()
    return Sha1Result(
        algorithm=ALGORITHM_NAME,
        digest_hex=h.hexdigest(),
        digest_length_bytes=len(digest),
        hex_length_chars=len(h.hexdigest()),
    )
