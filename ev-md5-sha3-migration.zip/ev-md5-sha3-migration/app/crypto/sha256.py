"""
sha256.py
=========

SHA-256 (SHA-2 family) remains widely used and is considered secure
for integrity purposes as of 2026: no practical collision or preimage
attacks are known. It is a Merkle-Damgard construction (same family
lineage as MD5/SHA-1, but with a much larger internal state and more
rounds, which is why it has not suffered the same collision breaks).

Included for comparison and because many real-world industrial/IoT
migrations choose SHA-256 as the pragmatic "safe default" over SHA-3,
purely for ecosystem/library support reasons -- a nuance this project
discusses explicitly rather than glossing over.
"""

from __future__ import annotations

import hashlib
from dataclasses import dataclass

ALGORITHM_NAME = "SHA-256"
IS_DEPRECATED = False
SECURITY_NOTE = (
    "SHA-256 has no known practical collision or preimage attacks and "
    "remains a widely trusted default. Its construction (Merkle-Damgard, "
    "256-bit output) differs from SHA-3's sponge construction; SHA-3 was "
    "standardized partly as a structurally independent backup in case "
    "future cryptanalysis found a weakness in the SHA-2 family."
)


@dataclass(frozen=True)
class Sha256Result:
    algorithm: str
    digest_hex: str
    digest_length_bytes: int
    hex_length_chars: int


def sha256_digest(data: bytes) -> Sha256Result:
    h = hashlib.sha256(data)
    digest = h.digest()
    return Sha256Result(
        algorithm=ALGORITHM_NAME,
        digest_hex=h.hexdigest(),
        digest_length_bytes=len(digest),
        hex_length_chars=len(h.hexdigest()),
    )
