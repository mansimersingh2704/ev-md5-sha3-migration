"""
comparison.py
=============

Side-by-side comparison of MD5 / SHA-1 / SHA-256 / SHA3-256 over the
same input, including a controlled execution-time benchmark. Used by
the dashboard's "Hash Comparison" panel and the /hash/compare API.
"""

from __future__ import annotations

import time
from dataclasses import dataclass, asdict
from typing import Any

from app.crypto import md5_legacy, sha1, sha256, sha3


@dataclass
class AlgorithmComparisonRow:
    algorithm: str
    digest_hex: str
    digest_length_bytes: int
    hex_length_chars: int
    avg_time_microseconds: float
    security_status: str
    modern_recommendation: str


def _benchmark(fn, data: bytes, rounds: int = 200) -> float:
    """Average wall-clock time in microseconds over `rounds` repetitions."""
    start = time.perf_counter()
    for _ in range(rounds):
        fn(data)
    elapsed = time.perf_counter() - start
    return (elapsed / rounds) * 1_000_000


def compare_all(message: dict[str, Any] | str, rounds: int = 200) -> list[dict[str, Any]]:
    """
    Compute MD5, SHA-1, SHA-256, and SHA3-256 over the same canonical
    input and return a comparison table plus a controlled micro-benchmark.

    NOTE ON THE BENCHMARK: raw hashing speed is NOT a security property.
    MD5 being fast is precisely why it is a poor choice where an
    adversary benefits from being able to brute-force or search a large
    space quickly (e.g. password hashing, or as shown in
    collision_fixture.py, birthday-attack search). Speed differences
    here are shown for completeness, not as a security recommendation.
    """
    if isinstance(message, dict):
        data = md5_legacy.canonical_serialize(message)
    else:
        data = message.encode("utf-8")

    rows: list[AlgorithmComparisonRow] = []

    md5_res = md5_legacy.md5_digest(data)
    rows.append(
        AlgorithmComparisonRow(
            algorithm=md5_res.algorithm,
            digest_hex=md5_res.digest_hex,
            digest_length_bytes=md5_res.digest_length_bytes,
            hex_length_chars=md5_res.hex_length_chars,
            avg_time_microseconds=_benchmark(lambda d: __import__("hashlib").md5(d).digest(), data, rounds),
            security_status="BROKEN - practical collisions since 2004. Never use for security decisions.",
            modern_recommendation="Do not use. Replace with SHA3-256 or SHA-256.",
        )
    )

    sha1_res = sha1.sha1_digest(data)
    rows.append(
        AlgorithmComparisonRow(
            algorithm=sha1_res.algorithm,
            digest_hex=sha1_res.digest_hex,
            digest_length_bytes=sha1_res.digest_length_bytes,
            hex_length_chars=sha1_res.hex_length_chars,
            avg_time_microseconds=_benchmark(lambda d: __import__("hashlib").sha1(d).digest(), data, rounds),
            security_status="DEPRECATED - practical chosen-prefix collisions since 2017/2020.",
            modern_recommendation="Do not use for new designs. Replace with SHA-256 or SHA3-256.",
        )
    )

    sha256_res = sha256.sha256_digest(data)
    rows.append(
        AlgorithmComparisonRow(
            algorithm=sha256_res.algorithm,
            digest_hex=sha256_res.digest_hex,
            digest_length_bytes=sha256_res.digest_length_bytes,
            hex_length_chars=sha256_res.hex_length_chars,
            avg_time_microseconds=_benchmark(lambda d: __import__("hashlib").sha256(d).digest(), data, rounds),
            security_status="SECURE - no known practical collision/preimage attacks.",
            modern_recommendation="Widely trusted default; fine to keep using.",
        )
    )

    sha3_res = sha3.sha3_256_digest(data)
    rows.append(
        AlgorithmComparisonRow(
            algorithm=sha3_res.algorithm,
            digest_hex=sha3_res.digest_hex,
            digest_length_bytes=sha3_res.digest_length_bytes,
            hex_length_chars=sha3_res.hex_length_chars,
            avg_time_microseconds=_benchmark(lambda d: __import__("hashlib").sha3_256(d).digest(), data, rounds),
            security_status="SECURE - structurally independent sponge construction (Keccak).",
            modern_recommendation="Recommended for new integrity designs; use HMAC-SHA3-256 for authenticity.",
        )
    )

    return [asdict(r) for r in rows]
