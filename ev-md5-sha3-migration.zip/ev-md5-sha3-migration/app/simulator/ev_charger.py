"""
ev_charger.py
=============

A simulated legacy EV charging station generating OCPP 1.6-STYLE
message payloads. This is NOT a full/compliant OCPP implementation
and it does not connect to any real charge point, CSMS, or network.
It exists purely to produce realistic-looking message structures for
the integrity/hashing demonstration.

SECURITY NOTE: Nothing in this module opens a socket, makes an HTTP
request, or talks to any external system. All data stays local.
"""

from __future__ import annotations

import random
import uuid
from datetime import datetime, timezone
from enum import Enum
from typing import Any


class OcppMessageType(str, Enum):
    BOOT_NOTIFICATION = "BootNotification"
    HEARTBEAT = "Heartbeat"
    STATUS_NOTIFICATION = "StatusNotification"
    METER_VALUES = "MeterValues"
    START_TRANSACTION = "StartTransaction"
    STOP_TRANSACTION = "StopTransaction"


_CHARGE_POINT_VENDORS = ["AcmeCharge", "VoltWorks", "GridPoint EV", "ChargeNow"]
_CHARGE_POINT_MODELS = ["CP-100", "CP-200S", "FastCharge-DC50", "AC-Wallbox-22"]
_STATUSES = ["Available", "Preparing", "Charging", "SuspendedEV", "Finishing", "Faulted"]


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _new_charger_id() -> str:
    return f"CP-{random.randint(1000, 9999)}"


def generate_message(
    message_type: OcppMessageType | str,
    charger_id: str | None = None,
) -> dict[str, Any]:
    """Generate a single realistic OCPP 1.6-style message payload."""
    if isinstance(message_type, str):
        message_type = OcppMessageType(message_type)

    charger_id = charger_id or _new_charger_id()
    message_id = str(uuid.uuid4())
    timestamp = _now_iso()

    base = {
        "message_id": message_id,
        "message_type": message_type.value,
        "charger_id": charger_id,
        "timestamp": timestamp,
    }

    if message_type is OcppMessageType.BOOT_NOTIFICATION:
        base["payload"] = {
            "chargePointVendor": random.choice(_CHARGE_POINT_VENDORS),
            "chargePointModel": random.choice(_CHARGE_POINT_MODELS),
            "firmwareVersion": f"1.{random.randint(0, 9)}.{random.randint(0, 20)}",
            "chargePointSerialNumber": f"SN{random.randint(100000, 999999)}",
        }
    elif message_type is OcppMessageType.HEARTBEAT:
        base["payload"] = {"currentTime": timestamp}
    elif message_type is OcppMessageType.STATUS_NOTIFICATION:
        base["payload"] = {
            "connectorId": random.randint(1, 2),
            "status": random.choice(_STATUSES),
            "errorCode": "NoError",
        }
    elif message_type is OcppMessageType.METER_VALUES:
        base["payload"] = {
            "connectorId": random.randint(1, 2),
            "transactionId": random.randint(10000, 99999),
            "meterValue": [
                {
                    "timestamp": timestamp,
                    "sampledValue": [
                        {"value": str(round(random.uniform(0, 50), 2)), "unit": "kWh"}
                    ],
                }
            ],
        }
    elif message_type is OcppMessageType.START_TRANSACTION:
        base["payload"] = {
            "connectorId": random.randint(1, 2),
            "idTag": f"TAG{random.randint(10000, 99999)}",
            "meterStart": random.randint(0, 1000),
            "timestamp": timestamp,
        }
    elif message_type is OcppMessageType.STOP_TRANSACTION:
        base["payload"] = {
            "transactionId": random.randint(10000, 99999),
            "idTag": f"TAG{random.randint(10000, 99999)}",
            "meterStop": random.randint(1000, 2000),
            "timestamp": timestamp,
            "reason": random.choice(["Local", "Remote", "EVDisconnected"]),
        }

    return base


def generate_random_message(charger_id: str | None = None) -> dict[str, Any]:
    """Generate a message of a randomly chosen OCPP type."""
    message_type = random.choice(list(OcppMessageType))
    return generate_message(message_type, charger_id)


def tamper_message(message: dict[str, Any]) -> dict[str, Any]:
    """
    Produce a deliberately tampered COPY of a message (does not mutate
    the input) by altering a value inside its payload -- simulating an
    attacker or a corrupted transmission changing meter values, status,
    or transaction identifiers in transit.
    """
    import copy

    tampered = copy.deepcopy(message)
    payload = tampered.get("payload", {})

    if "meterStop" in payload:
        payload["meterStop"] = payload["meterStop"] + random.randint(50, 500)
    elif "meterStart" in payload:
        payload["meterStart"] = payload["meterStart"] + random.randint(50, 500)
    elif "status" in payload:
        payload["status"] = "Available" if payload["status"] != "Available" else "Faulted"
    elif "meterValue" in payload:
        try:
            payload["meterValue"][0]["sampledValue"][0]["value"] = str(
                round(random.uniform(50, 200), 2)
            )
        except (KeyError, IndexError):
            payload["_tampered_marker"] = True
    else:
        payload["_tampered_marker"] = True

    tampered["payload"] = payload
    return tampered
