"""
db_models.py
============

SQLAlchemy ORM models for the local SQLite lab database.
"""

from __future__ import annotations

from datetime import datetime, timezone

from sqlalchemy import DateTime, Integer, String, Text, Boolean
from sqlalchemy.orm import Mapped, mapped_column

from app.core.db import Base


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


class MessageRecord(Base):
    __tablename__ = "messages"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    timestamp: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)
    charger_id: Mapped[str] = mapped_column(String(64))
    message_type: Mapped[str] = mapped_column(String(64))
    payload_json: Mapped[str] = mapped_column(Text)  # full wrapped-message JSON
    md5: Mapped[str | None] = mapped_column(String(32), nullable=True)
    sha3_256: Mapped[str | None] = mapped_column(String(64), nullable=True)
    hmac_sha3_256: Mapped[str | None] = mapped_column(String(64), nullable=True)
    migration_mode: Mapped[str] = mapped_column(String(16))
    verification_method: Mapped[str | None] = mapped_column(String(16), nullable=True)
    verification_status: Mapped[str | None] = mapped_column(String(16), nullable=True)  # VALID / INVALID / UNVERIFIED
    is_tampered: Mapped[bool] = mapped_column(Boolean, default=False)


class MigrationEvent(Base):
    __tablename__ = "migration_events"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    timestamp: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)
    old_algorithm: Mapped[str] = mapped_column(String(32))
    new_algorithm: Mapped[str] = mapped_column(String(32))
    status: Mapped[str] = mapped_column(String(32))
    details: Mapped[str] = mapped_column(Text)


class CollisionDemoEvent(Base):
    __tablename__ = "collision_demo_events"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    timestamp: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=_utcnow)
    truncate_bits: Mapped[int] = mapped_column(Integer)
    message_a: Mapped[str] = mapped_column(Text)
    message_b: Mapped[str] = mapped_column(Text)
    iterations: Mapped[int] = mapped_column(Integer)
    search_time_seconds: Mapped[float] = mapped_column(Integer)
    truncated_md5_equal: Mapped[bool] = mapped_column(Boolean)
    sha3_256_equal: Mapped[bool] = mapped_column(Boolean)
