"""
schemas.py
==========

Pydantic models for API request/response validation.
"""

from __future__ import annotations

from datetime import datetime
from typing import Any, Optional

from pydantic import BaseModel, Field


class GenerateMessageRequest(BaseModel):
    message_type: Optional[str] = Field(
        default=None,
        description="OCPP message type, e.g. BootNotification. Random if omitted.",
    )
    charger_id: Optional[str] = None
    migration_mode: str = Field(default="HYBRID", description="LEGACY | HYBRID | MODERN")


class MessageResponse(BaseModel):
    id: int
    timestamp: datetime
    charger_id: str
    message_type: str
    payload: dict[str, Any]
    wrapped: dict[str, Any]
    migration_mode: str
    verification_method: Optional[str] = None
    verification_status: Optional[str] = None
    is_tampered: bool

    class Config:
        from_attributes = True


class VerifyMessageRequest(BaseModel):
    message_id: int
    allow_legacy_fallback: bool = False


class VerifyMessageResponse(BaseModel):
    message_id: int
    valid: bool
    method_used: str
    migration_mode: str
    downgraded: bool
    details: str


class TamperMessageRequest(BaseModel):
    message_id: int


class HashCompareRequest(BaseModel):
    text: Optional[str] = None
    message_id: Optional[int] = None
    rounds: int = 200


class CollisionDemoRequest(BaseModel):
    truncate_bits: int = 24


class MigrationVerifyRequest(BaseModel):
    wrapped_message: dict[str, Any]
    allow_legacy_fallback: bool = False


class SystemStatusResponse(BaseModel):
    legacy_algorithm: str
    current_default_mode: str
    total_messages: int
    integrity_failures: int
    collision_demo_runs: int
    tampered_messages: int
