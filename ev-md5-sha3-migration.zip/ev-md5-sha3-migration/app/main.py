"""
main.py
=======

FastAPI application entrypoint for the EV MD5->SHA-3 Migration Lab.

Run locally with:
    uvicorn app.main:app --reload

Dashboard:  http://127.0.0.1:8000/
API docs:   http://127.0.0.1:8000/docs
"""

from __future__ import annotations

from pathlib import Path

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse

from app.api import analysis, messages
from app.core.db import init_db
from app.core.logging_config import logger

FRONTEND_DIR = Path(__file__).resolve().parents[1] / "frontend"

app = FastAPI(
    title="EV MD5-to-SHA-3 Migration Lab",
    description=(
        "Local, offline academic lab demonstrating MD5 integrity risk in "
        "legacy EV/OCPP-style firmware and a backward-compatible SHA-3 "
        "migration wrapper. No connections are made to real EV charging "
        "infrastructure."
    ),
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://127.0.0.1:8000", "http://localhost:8000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(messages.router, prefix="/api")
app.include_router(analysis.router, prefix="/api")


@app.on_event("startup")
def on_startup() -> None:
    init_db()
    logger.info("EV MD5->SHA-3 Migration Lab started. Local-only, no external network calls.")


@app.get("/", include_in_schema=False)
def dashboard():
    return FileResponse(FRONTEND_DIR / "index.html")


app.mount("/static", StaticFiles(directory=str(FRONTEND_DIR)), name="static")
