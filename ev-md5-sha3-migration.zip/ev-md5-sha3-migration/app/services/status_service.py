"""
status_service.py
==================

Aggregates counters for the dashboard's System Overview panel.
"""

from __future__ import annotations

from sqlalchemy.orm import Session

from app.models.db_models import MessageRecord, CollisionDemoEvent
from app.services import collision_service


def get_system_status(db: Session, current_default_mode: str) -> dict:
    total_messages = db.query(MessageRecord).count()
    integrity_failures = (
        db.query(MessageRecord).filter(MessageRecord.verification_status == "INVALID").count()
    )
    tampered_messages = db.query(MessageRecord).filter(MessageRecord.is_tampered.is_(True)).count()
    collision_runs = collision_service.collision_demo_run_count(db)

    return {
        "legacy_algorithm": "MD5",
        "current_default_mode": current_default_mode,
        "total_messages": total_messages,
        "integrity_failures": integrity_failures,
        "collision_demo_runs": collision_runs,
        "tampered_messages": tampered_messages,
    }
