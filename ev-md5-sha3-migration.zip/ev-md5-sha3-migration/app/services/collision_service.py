"""
collision_service.py
=====================

Runs the local, verifiable truncated-MD5 collision demo and persists
each run so the dashboard's "System Overview" can show whether a
collision demo has been run and how many times.
"""

from __future__ import annotations

from sqlalchemy.orm import Session

from app.core.logging_config import logger
from app.crypto import collision_fixture
from app.models.db_models import CollisionDemoEvent


def run_collision_demo(db: Session, truncate_bits: int = 24) -> collision_fixture.CollisionResult:
    result = collision_fixture.find_truncated_md5_collision(truncate_bits=truncate_bits)

    event = CollisionDemoEvent(
        truncate_bits=result.truncate_bits,
        message_a=result.message_a,
        message_b=result.message_b,
        iterations=result.iterations,
        search_time_seconds=result.search_time_seconds,
        truncated_md5_equal=result.truncated_md5_equal,
        sha3_256_equal=result.sha3_256_equal,
    )
    db.add(event)
    db.commit()

    logger.warning(
        "Collision demo run: bits=%s iterations=%s truncated_md5_equal=%s sha3_equal=%s",
        result.truncate_bits, result.iterations, result.truncated_md5_equal, result.sha3_256_equal,
    )
    return result


def collision_demo_run_count(db: Session) -> int:
    return db.query(CollisionDemoEvent).count()
