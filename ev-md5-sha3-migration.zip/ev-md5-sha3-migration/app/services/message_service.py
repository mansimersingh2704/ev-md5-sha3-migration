"""
message_service.py
===================

Orchestrates: generate an EV message -> wrap it per the current
migration mode -> store it -> verify it -> tamper with it. This is
the glue between the simulator, the crypto/migration layer, and the
SQLite persistence layer.
"""

from __future__ import annotations

import json
from typing import Any, Optional

from sqlalchemy.orm import Session

from app.core.logging_config import logger
from app.crypto import migration
from app.models.db_models import MessageRecord
from app.simulator import ev_charger


def create_message(
    db: Session,
    message_type: Optional[str],
    charger_id: Optional[str],
    migration_mode: str,
) -> MessageRecord:
    mode = migration.MigrationMode(migration_mode)

    if message_type:
        raw_message = ev_charger.generate_message(message_type, charger_id)
    else:
        raw_message = ev_charger.generate_random_message(charger_id)

    wrapped = migration.wrap_message(raw_message, mode)
    wrapped_dict = wrapped.to_dict()

    record = MessageRecord(
        charger_id=raw_message["charger_id"],
        message_type=raw_message["message_type"],
        payload_json=json.dumps(wrapped_dict),
        md5=wrapped.legacy_md5,
        sha3_256=wrapped.sha3_256,
        hmac_sha3_256=wrapped.hmac_sha3_256,
        migration_mode=mode.value,
        verification_method=None,
        verification_status="UNVERIFIED",
        is_tampered=False,
    )
    db.add(record)
    db.commit()
    db.refresh(record)

    logger.info(
        "Created message id=%s type=%s charger=%s mode=%s",
        record.id, record.message_type, record.charger_id, mode.value,
    )
    return record


def get_message(db: Session, message_id: int) -> Optional[MessageRecord]:
    return db.get(MessageRecord, message_id)


def list_messages(db: Session, limit: int = 100) -> list[MessageRecord]:
    return (
        db.query(MessageRecord)
        .order_by(MessageRecord.id.desc())
        .limit(limit)
        .all()
    )


def verify_message(
    db: Session, message_id: int, allow_legacy_fallback: bool = False
) -> tuple[MessageRecord, migration.VerificationResult]:
    record = get_message(db, message_id)
    if record is None:
        raise ValueError(f"Message {message_id} not found.")

    wrapped_dict = json.loads(record.payload_json)
    result = migration.verify_wrapped_message(wrapped_dict, allow_legacy_fallback=allow_legacy_fallback)

    record.verification_method = result.method_used.value
    record.verification_status = "VALID" if result.valid else "INVALID"
    db.commit()
    db.refresh(record)

    log_fn = logger.info if result.valid else logger.warning
    log_fn(
        "Verified message id=%s method=%s valid=%s downgraded=%s",
        message_id, result.method_used.value, result.valid, result.downgraded,
    )
    return record, result


def tamper_message(db: Session, message_id: int) -> tuple[MessageRecord, migration.VerificationResult]:
    """
    Create a NEW message record representing a tampered copy of an
    existing one: the inner legacy_message payload is altered but the
    ORIGINAL integrity metadata (MD5/SHA3/HMAC) is kept unchanged --
    exactly what happens if an attacker (or corruption) modifies a
    message in transit without being able to regenerate a valid
    integrity value. Verification is then run to show detection.
    """
    original = get_message(db, message_id)
    if original is None:
        raise ValueError(f"Message {message_id} not found.")

    wrapped_dict: dict[str, Any] = json.loads(original.payload_json)
    tampered_inner = ev_charger.tamper_message(wrapped_dict["legacy_message"])

    tampered_wrapped = dict(wrapped_dict)
    tampered_wrapped["legacy_message"] = tampered_inner
    # NOTE: integrity fields (legacy_md5 / sha3_256 / hmac_sha3_256) are
    # deliberately NOT recomputed -- this simulates an attacker/corruption
    # event that changes the message but cannot produce a matching
    # integrity value.

    record = MessageRecord(
        charger_id=original.charger_id,
        message_type=original.message_type,
        payload_json=json.dumps(tampered_wrapped),
        md5=tampered_wrapped.get("legacy_md5"),
        sha3_256=tampered_wrapped.get("sha3_256"),
        hmac_sha3_256=tampered_wrapped.get("hmac_sha3_256"),
        migration_mode=original.migration_mode,
        verification_method=None,
        verification_status="UNVERIFIED",
        is_tampered=True,
    )
    db.add(record)
    db.commit()
    db.refresh(record)

    result = migration.verify_wrapped_message(tampered_wrapped, allow_legacy_fallback=False)
    record.verification_method = result.method_used.value
    record.verification_status = "VALID" if result.valid else "INVALID"
    db.commit()
    db.refresh(record)

    logger.warning(
        "Tampered message created id=%s (from id=%s) detection_valid=%s (expected False)",
        record.id, message_id, result.valid,
    )
    return record, result


def to_response_dict(record: MessageRecord) -> dict[str, Any]:
    wrapped = json.loads(record.payload_json)
    return {
        "id": record.id,
        "timestamp": record.timestamp,
        "charger_id": record.charger_id,
        "message_type": record.message_type,
        "payload": wrapped.get("legacy_message", {}),
        "wrapped": wrapped,
        "migration_mode": record.migration_mode,
        "verification_method": record.verification_method,
        "verification_status": record.verification_status,
        "is_tampered": record.is_tampered,
    }
