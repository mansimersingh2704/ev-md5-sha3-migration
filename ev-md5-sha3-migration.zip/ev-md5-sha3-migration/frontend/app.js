const API = "/api";
let currentMessage = null;

// ---------- Tabs ----------
document.querySelectorAll(".tab-btn").forEach(btn => {
  btn.addEventListener("click", () => {
    document.querySelectorAll(".tab-btn").forEach(b => b.classList.remove("active"));
    document.querySelectorAll(".tab-panel").forEach(p => p.classList.remove("active"));
    btn.classList.add("active");
    document.getElementById(btn.dataset.tab).classList.add("active");
    if (btn.dataset.tab === "overview") loadOverview();
    if (btn.dataset.tab === "migration") loadModes();
  });
});

// ---------- Overview ----------
async function loadOverview() {
  const status = await fetch(`${API}/system/status`).then(r => r.json());
  document.getElementById("ov-legacy-algo").textContent = status.legacy_algorithm;
  document.getElementById("ov-mode").textContent = status.current_default_mode;
  document.getElementById("ov-messages").textContent = status.total_messages;
  document.getElementById("ov-failures").textContent = status.integrity_failures;
  document.getElementById("ov-tampered").textContent = status.tampered_messages;
  document.getElementById("ov-collisions").textContent = status.collision_demo_runs;
  document.getElementById("mode-select").value = status.current_default_mode;

  const messages = await fetch(`${API}/messages?limit=15`).then(r => r.json());
  const tbody = document.querySelector("#recent-messages-table tbody");
  tbody.innerHTML = "";
  messages.forEach(m => {
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td>${m.id}</td><td>${m.message_type}</td><td>${m.charger_id}</td>
      <td>${m.migration_mode}</td><td>${m.verification_method ?? "—"}</td>
      <td>${statusBadge(m.verification_status)}</td>
      <td>${m.is_tampered ? "⚠️ yes" : "no"}</td>`;
    tbody.appendChild(tr);
  });
}

function statusBadge(status) {
  if (status === "VALID") return `<span class="badge ok">VALID</span>`;
  if (status === "INVALID") return `<span class="badge bad">INVALID</span>`;
  return `<span class="badge warn">UNVERIFIED</span>`;
}

document.getElementById("set-mode-btn").addEventListener("click", async () => {
  const mode = document.getElementById("mode-select").value;
  await fetch(`${API}/migration/mode?mode=${mode}`, { method: "POST" });
  loadOverview();
});

// ---------- Hash Comparison ----------
document.getElementById("compare-btn").addEventListener("click", async () => {
  const text = document.getElementById("compare-input").value;
  const body = text.trim() ? { text, rounds: 200 } : (currentMessage ? { message_id: currentMessage.id, rounds: 200 } : { text: "EV-CSMS-lab-demo-message", rounds: 200 });
  const res = await fetch(`${API}/hash/compare`, {
    method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body)
  }).then(r => r.json());

  const tbody = document.querySelector("#compare-table tbody");
  tbody.innerHTML = "";
  res.rows.forEach(row => {
    const tr = document.createElement("tr");
    const secClass = row.security_status.startsWith("SECURE") ? "ok" : row.security_status.startsWith("DEPRECATED") ? "warn" : "bad";
    tr.innerHTML = `
      <td><strong>${row.algorithm}</strong></td>
      <td class="mono">${row.digest_hex}</td>
      <td>${row.digest_length_bytes} bytes</td>
      <td>${row.hex_length_chars} chars</td>
      <td>${row.avg_time_microseconds.toFixed(2)}</td>
      <td><span class="badge ${secClass}">${row.security_status}</span></td>
      <td>${row.modern_recommendation}</td>`;
    tbody.appendChild(tr);
  });
});

// ---------- Simulator ----------
document.getElementById("sim-generate-btn").addEventListener("click", async () => {
  const message_type = document.getElementById("sim-msg-type").value || null;
  const migration_mode = document.getElementById("sim-mode").value;
  const msg = await fetch(`${API}/messages`, {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ message_type, migration_mode })
  }).then(r => r.json());
  currentMessage = msg;
  document.getElementById("sim-message-json").textContent = JSON.stringify(msg.wrapped, null, 2);
  document.getElementById("sim-verify-btn").disabled = false;
  document.getElementById("sim-tamper-btn").disabled = false;
  document.getElementById("sim-verify-result").innerHTML = "";
  document.getElementById("sim-explainer").innerHTML =
    `Generated a <strong>${msg.message_type}</strong> message from charger <strong>${msg.charger_id}</strong> ` +
    `in <strong>${msg.migration_mode}</strong> mode. The wrapper's <code>legacy_message</code> field is exactly ` +
    `what a legacy CSMS parser would consume — unchanged. Click "Verify Integrity" to check it, or "Tamper Message" ` +
    `to simulate an attacker/corruption event and see detection in action.`;
});

document.getElementById("sim-verify-btn").addEventListener("click", async () => {
  if (!currentMessage) return;
  const result = await fetch(`${API}/messages/verify`, {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ message_id: currentMessage.id, allow_legacy_fallback: false })
  }).then(r => r.json());
  renderVerifyResult("sim-verify-result", result);
  loadOverview();
});

document.getElementById("sim-tamper-btn").addEventListener("click", async () => {
  if (!currentMessage) return;
  const tampered = await fetch(`${API}/messages/tamper`, {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ message_id: currentMessage.id })
  }).then(r => r.json());
  currentMessage = tampered;
  document.getElementById("sim-message-json").textContent = JSON.stringify(tampered.wrapped, null, 2);
  renderVerifyResult("sim-verify-result", {
    valid: tampered.verification_status === "VALID",
    method_used: tampered.verification_method,
    details: "Message payload was altered but its original integrity metadata was kept unchanged " +
             "(exactly what an attacker able to modify data but not regenerate a valid digest would produce)."
  });
  document.getElementById("sim-explainer").innerHTML =
    `⚠️ This message has been <strong>tampered</strong>: its content changed but the integrity value was not regenerated. ` +
    `Verification correctly flags it as <strong>INVALID</strong> — this is accidental-corruption-style detection, not proof of who tampered with it.`;
  loadOverview();
});

function renderVerifyResult(elId, result) {
  const el = document.getElementById(elId);
  el.className = "result-box " + (result.valid ? "valid" : "invalid");
  el.innerHTML = `<strong>${result.valid ? "✅ VALID" : "❌ INVALID"}</strong> — method: ${result.method_used}` +
    (result.downgraded ? ` <span class="badge warn">DOWNGRADED</span>` : "") +
    `<br/><span class="hint">${result.details}</span>`;
}

// ---------- Collision Demo ----------
document.getElementById("collision-btn").addEventListener("click", async () => {
  const bits = document.getElementById("collision-bits").value || 24;
  const resultEl = document.getElementById("collision-result");
  resultEl.innerHTML = `<p class="hint">Running local brute-force search…</p>`;
  const res = await fetch(`${API}/collision-demo?truncate_bits=${bits}`).then(r => r.json());
  resultEl.innerHTML = `
    <div class="table-wrap"><table>
      <thead><tr><th></th><th>Message A</th><th>Message B</th></tr></thead>
      <tbody>
        <tr><td>Raw message</td><td class="mono">${res.message_a}</td><td class="mono">${res.message_b}</td></tr>
        <tr><td>Truncated MD5 (${res.truncate_bits} bits)</td><td class="mono">${res.truncated_md5_a}</td><td class="mono">${res.truncated_md5_b}</td></tr>
        <tr><td>Full MD5 (128-bit)</td><td class="mono">${res.full_md5_a}</td><td class="mono">${res.full_md5_b}</td></tr>
        <tr><td>SHA3-256</td><td class="mono">${res.sha3_256_a}</td><td class="mono">${res.sha3_256_b}</td></tr>
      </tbody>
    </table></div>
    <div class="row" style="margin-top:12px">
      <span class="badge ${res.truncated_md5_equal ? "bad" : "ok"}">Truncated MD5 collision: ${res.truncated_md5_equal ? "YES" : "no"}</span>
      <span class="badge ${res.full_md5_equal ? "bad" : "ok"}">Full MD5 equal: ${res.full_md5_equal ? "YES" : "no"}</span>
      <span class="badge ${res.sha3_256_equal ? "bad" : "ok"}">SHA3-256 equal: ${res.sha3_256_equal ? "YES" : "no"}</span>
    </div>
    <p class="hint" style="margin-top:10px">${res.explanation}<br/>
    Found in ${res.iterations} attempts (${res.search_time_seconds.toFixed(4)}s).</p>`;
  loadOverview();
});

// ---------- Migration Demo ----------
async function loadModes() {
  const data = await fetch(`${API}/migration/modes`).then(r => r.json());
  const tbody = document.querySelector("#modes-table tbody");
  tbody.innerHTML = "";
  data.summary.forEach(row => {
    const tr = document.createElement("tr");
    tr.innerHTML = `<td><strong>${row.mode}</strong></td><td>${row.guarantee}</td><td>${row.risk}</td>`;
    tbody.appendChild(tr);
  });
}

document.getElementById("migration-verify-btn").addEventListener("click", async () => {
  const raw = document.getElementById("migration-verify-input").value;
  let wrapped;
  try {
    wrapped = JSON.parse(raw);
  } catch (e) {
    document.getElementById("migration-verify-result").innerHTML = `<span class="badge bad">Invalid JSON</span>`;
    return;
  }
  const allow = document.getElementById("allow-fallback-checkbox").checked;
  const result = await fetch(`${API}/migration/verify`, {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ wrapped_message: wrapped, allow_legacy_fallback: allow })
  }).then(r => r.json());
  renderVerifyResult("migration-verify-result", result);
});

// ---------- Init ----------
loadOverview();
loadModes();
